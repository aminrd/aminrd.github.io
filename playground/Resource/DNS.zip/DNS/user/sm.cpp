//                   In the name of GOD
/**
 * Partov is a simulation engine, supporting emulation as well,
 * making it possible to create virtual networks.
 *  
 * Copyright © 2009-2014 Behnam Momeni.
 * 
 * This file is part of the Partov.
 * 
 * Partov is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Partov is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Partov.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * =====================================================================
 * == Mohammad Amin Aghaee Rad -- 90105634                            ==
 * == Course: Computer Networks                                       ==
 * == Programming assignment2                                         ==
 * =====================================================================
 */
#include "sm.h"

#include "interface.h"
#include "frame.h"

#include <netinet/in.h>
#include <sr_protocol.h>

#include <iostream>
#include <iomanip>
#include <cstdio>
#include <stdlib.h>

#include <string>
#include <string.h>
#include <cstring>
#include <sstream>

#include <vector>
#include <thread>
#include <pthread.h>
#include <time.h>
#include <unistd.h>
using namespace std;

#define PRINTIP(x) (x>>24)<<"."<<(x>>16)%256<<"."<<(x>>8)%256<<"."<<x%256

#ifndef FOR
#define FOR(i,x) for(uint32_t i=0; i<(x); i++)
#endif

static uint16_t broadcast_port = 5000;

void mac_copy(mac_addr* dst, mac_addr* src){
    FOR(j,ETHER_ADDR_LEN)
        dst->data[j] = src->data[j];
    return;
}
bool mac_compare(mac_addr* a, mac_addr* b){
    FOR(i, ETHER_ADDR_LEN)
        if( a->data[i] != b->data[i] )
            return false;
    return true;
}
uint16_t calculateIPCheckSum(ip *ipheader){
    uint16_t word16;
    uint32_t sum=0;
    uint16_t i;
    uint16_t len_ip_header = ipheader->ip_hl*4;
    const uint8_t *buff;
    buff = (uint8_t *)ipheader;
    for (i=0;i<len_ip_header;i=i+2){
        word16 =((buff[i]<<8)&0xFF00)+(buff[i+1]&0xFF);
        sum = sum + (uint32_t) word16;
    }
    while (sum>>16)
        sum = (sum & 0xFFFF)+(sum >> 16);
    sum = ~sum;
    return ((uint16_t) sum);
}
uint16_t calculateIcmpCheckSum(sr_icmp *icmpheader){
    uint16_t word16;
    uint32_t sum=0;
    uint16_t i;
    uint16_t length = sizeof(sr_icmp);
    const uint8_t *buff;
    buff = (uint8_t *)icmpheader;
    for (i=0;i<length;i=i+2){
        word16 =((buff[i]<<8)&0xFF00)+(buff[i+1]&0xFF);
        sum = sum + (uint32_t) word16;
    }
    while (sum>>16)
        sum = (sum & 0xFFFF)+(sum >> 16);
    sum = ~sum;
    return ((uint16_t) sum);
}

// ###### MESSAGE ######
// -------------------------------------------------- Functions and constructors:
message::message(SimulatedMachine* my_friend, int Iface_num, custom_msg_header* TH){
    main_machine = my_friend;
    iface_num = Iface_num;
    memcpy(&tl, TH, sizeof(custom_msg_header));
    if( Iface_num == 1 )
        mac_copy( &(tl.dst_mac), &(my_friend->gatewayMac) );
    
    mac_copy(&tl.src_mac, &(my_friend->my_macs[iface_num]));
}

message::message(SimulatedMachine* my_friend, int Iface_num,Frame* input_frame){
    main_machine = my_friend;
    iface_num = Iface_num;
    buffer_size = input_frame->length;
#ifdef DBG_MOD
    if( buffer_size >= BUFFER_SIZE )
        cerr<<"::ERROR: The size of new frame is too big!\n";
#endif
    
    // checking ethernet header validation:
    memcpy((void*) &buffer, (void*)input_frame->data, buffer_size);
    sr_ethernet_hdr *ether_head = (sr_ethernet_hdr *)&(input_frame->data[0]);
    FOR(j,ETHER_ADDR_LEN){
        tl.dst_mac.data[j] = ether_head->ether_dhost[j];
        tl.src_mac.data[j] = ether_head->ether_shost[j];
    }
    if( ntohs(ether_head->ether_type) != ETHERTYPE_IP ){
#ifdef DBG_MOD
        cerr<<"::ERRO: ethernet header couldn't match IP_HEADER"<<endl;
#endif
        throw 0;
    }
    
    // checking ip header validation:
    ip *ip_packet=(ip *)&(input_frame->data[14]);
    if( (ip_packet->ip_p != IPPROTO_UDP &&  ip_packet->ip_p != 0x01) ){
#ifdef DBG_MOD
        cerr<<"::ERROR: IP header couldn't match UDP or ICMP"<<endl;
#endif
        throw 1;
    }
    uint16_t prev_checksum = ntohs(ip_packet->ip_sum);
    ip_packet->ip_sum = 0;
    uint16_t new_checksum = calculateIPCheckSum(ip_packet);
    ip_packet->ip_sum = htons(prev_checksum);
    if( prev_checksum != new_checksum ){
#ifdef DBG_MOD
        cerr<<"::ERROR: ip checksum is wrong!"<<endl;
#endif
        throw 2;
    }
    tl.sender.ip = ntohl( (ip_packet->ip_src).s_addr );
    tl.reciever.ip = ntohl( (ip_packet->ip_dst).s_addr );
    
    // checking (udp/icmp) header validation:
    if( ip_packet->ip_p == IPPROTO_ICMP ){// ICMP
        sr_icmp* icmp_header = (sr_icmp *) &(input_frame->data[34]);
        uint16_t prev_icmp_sum = ntohs(icmp_header->checksum);
        icmp_header->checksum = 0;
        uint16_t new_icmp_sum = calculateIcmpCheckSum(icmp_header);
        icmp_header->checksum = htons(prev_icmp_sum);
        if( prev_icmp_sum != new_icmp_sum ){
#ifdef DBG_MOD
            cerr<<"::ERROR: icmp checksum is wrong!"<<endl;
#endif
            throw 3;
        }
        tl.type = 2;
        tl.icmp_type = icmp_header->type;
        tl.sequenceNumber = ntohs(icmp_header->seq_num);
    }else{// UDP
        sr_udp* udp_header = (sr_udp *) &(input_frame->data[34]);
        tl.sender.port = ntohs(udp_header->port_src);
        tl.reciever.port = ntohs(udp_header->port_dst);
        int idx = 34+sizeof(sr_udp);
        
        if(tl.sender.port == broadcast_port && tl.reciever.port == broadcast_port){// advertisement
            tl.type = 0;
            tl.adv_num = 0;
            sr_broadcast* tmp;
            
            while( (uint32_t)input_frame->data[idx] != 0 ){
                tmp = (sr_broadcast*) &(input_frame->data[idx]);
                idx += sizeof(sr_broadcast);
                
                tl.server_nodes[tl.adv_num].server_ip = ntohl(tmp->server_ip);
                tl.server_nodes[tl.adv_num].RTT = ntohl(tmp->RTT);
                tl.server_nodes[tl.adv_num].sent_cnt = ntohs(tmp->sent_cnt);
                tl.server_nodes[tl.adv_num].rcv_cnt = ntohs(tmp->rcv_cnt);
                tl.adv_num++;
            }
            #ifdef DBG_MOD
                        cerr<<"++++ adv message recieved & parsed; size = "<<tl.adv_num<<endl;
            #endif
        }else{// application
            tl.type = 1;
            uint32_t* phony = (uint32_t*) &(input_frame->data[idx]);
            if( ntohl(*phony) != 0x12345678 ){
#ifdef DBG_MOD
                cerr<<"::ERRO: Applicatoin data is incorrect!"<<endl;
#endif
            }
        }
    }
#ifdef DBG_MOD
        cerr<<"++++++ frame parsed successfully!"<<endl;
#endif
}

Frame message::generate_frame(){
    
    uint32_t size_after_ip = 0;
    if(tl.type ==0)// advertise
        size_after_ip = sizeof(sr_udp) + tl.adv_num * sizeof(sr_broadcast) + 4;
    else if(tl.type == 1) // application
        size_after_ip = sizeof(sr_udp) + 4;
    else // icmp
        size_after_ip = sizeof(sr_icmp);
    
    buffer_size = sizeof(sr_ethernet_hdr) + sizeof(ip) + size_after_ip;
    uint8_t* buff_addr = buffer;
    
    // set ethernet header:
    struct sr_ethernet_hdr eth_header;
    FOR(j,ETHER_ADDR_LEN){
        if( tl.type ==  0)
            eth_header.ether_dhost[j] = 0xff;
        else
            eth_header.ether_dhost[j] = tl.dst_mac.data[j];
        
        eth_header.ether_shost[j] = tl.src_mac.data[j];
    }
    eth_header.ether_type = htons(ETHERTYPE_IP);
    
    memcpy((void*)buff_addr, (void*) (&eth_header), sizeof(sr_ethernet_hdr));
    buff_addr += sizeof(sr_ethernet_hdr);
    
    // set ip header:
    struct ip ip_header;
    ip_header.ip_v = 4;
    ip_header.ip_hl = 5;
    ip_header.ip_tos = 0;
    ip_header.ip_len = htons(sizeof(ip) + size_after_ip);
    ip_header.ip_id = htons(0);
    ip_header.ip_off = htons(0);
    ip_header.ip_ttl = 0x40;
    
    if(tl.type == 2)
        ip_header.ip_p = IPPROTO_ICMP; // ICMP
    else
        ip_header.ip_p = IPPROTO_UDP; // UDP
    
    ip_header.ip_sum = 0;
    ip_header.ip_src.s_addr = htonl( tl.sender.ip );
    
    if(tl.type == 0)
        ip_header.ip_dst.s_addr = htonl( INFINITY );
    else
        ip_header.ip_dst.s_addr = htonl( tl.reciever.ip );
    
    ip_header.ip_sum = htons(calculateIPCheckSum(&ip_header));
    memcpy((void*)buff_addr, (void*) (&ip_header), sizeof(ip_header));
    buff_addr += sizeof(ip_header);
    
    if(tl.type == 2){// ICMP MESSAGE
        sr_icmp icmp_header;
        icmp_header.type = tl.icmp_type;
        icmp_header.code = 0;
        icmp_header.checksum = 0 ;
        icmp_header.ID = 0;
        icmp_header.seq_num = htons(tl.sequenceNumber);
        icmp_header.data = htonl(0x12345678);
        icmp_header.checksum = htons( calculateIcmpCheckSum(&icmp_header) );
        
        memcpy((void*)buff_addr, (void*) (&icmp_header), sizeof(sr_icmp));
        buff_addr += sizeof(sr_icmp);
    }else{
        sr_udp udp_header;
        udp_header.port_src = htons(tl.sender.port);
        udp_header.port_dst = htons(tl.reciever.port);
        udp_header.length = htons(size_after_ip);
        udp_header.udp_sum = htons(0);
        
        memcpy((void*)buff_addr, (void*) (&udp_header), sizeof(sr_udp));
        buff_addr += sizeof(sr_udp);
        
        if(tl.type == 1){// APPLICATION MESSAGE
            uint32_t app_msg = htonl(0x12345678);
            memcpy((void*)buff_addr, (void*) &app_msg, sizeof(uint32_t));
            buff_addr += sizeof(uint32_t);
            
        }else{// ADVERTISEMENT MESSAGE
            sr_broadcast tmp;
            FOR(i, tl.adv_num){
                memcpy( (void*)&tmp, (void*)&(tl.server_nodes[i]), sizeof(sr_broadcast));
                
                tmp.server_ip = htonl(tmp.server_ip);
                tmp.RTT = htonl(tmp.RTT);
                tmp.sent_cnt = htons(tmp.sent_cnt);
                tmp.rcv_cnt = htons(tmp.rcv_cnt);
                
                memcpy((void*)buff_addr, (void*)&tmp, sizeof(sr_broadcast));
                buff_addr += sizeof(sr_broadcast);
            }
            uint32_t zero = 0;
            memcpy((void*)buff_addr, (void*) &zero, sizeof(uint32_t));
            buff_addr += sizeof(uint32_t);
        }
    }
#ifdef DBG_MOD
    cerr<<"------ new frame details: "<<endl;
    cerr<<":: src mac: ";
    FOR(j,6)
        cerr<<std::hex<<(int)eth_header.ether_shost[j]<<":";
    cerr<<"\n:: dst mac: ";
    FOR(j,6)
        cerr<<std::hex<<(int)eth_header.ether_dhost[j]<<":";
    cerr<<endl;
    
    cerr<<dec;
    cerr<<" :: buffer_size = "<<this->buffer_size<<endl;
    cerr<<" -- from:"<<PRINTIP(ntohl(ip_header.ip_src.s_addr))<<" + "<<tl.sender.port<<endl;
    cerr<<" -- to:"<<PRINTIP(ntohl(ip_header.ip_dst.s_addr))<<" + "<<tl.reciever.port<<endl;
    
    if( (buff_addr -  buffer) != buffer_size)
        cerr<<"::ERROR -> buffer size\n"<<endl;
#endif
//    test_frame = new Frame(buffer_size, buffer);
    Frame frame(buffer_size, buffer);
#ifdef DBG_MOD
    FOR(i, frame.length){
        if( i==sizeof(sr_ethernet_hdr) || i==(sizeof(sr_ethernet_hdr) + sizeof(ip)) )
            cerr<<"\n";
        
        if( i< sizeof(sr_ethernet_hdr))
            cerr<<std::hex<<(int)frame.data[i]<<" ";
        else
            cerr<<std::dec<<(int)frame.data[i]<<" ";
    }
    cerr<<"\n";
#endif
    return frame;
}

Frame message::forward_to_mac( mac_addr* f_mac, uint32_t ifc){
    FOR(j, ETHER_ADDR_LEN){
        buffer[j] = f_mac->data[j];
        buffer[j + ETHER_ADDR_LEN] = main_machine->my_macs[ifc].data[j];
    }
    Frame frame(buffer_size, buffer);
    return frame;
}

// ###### ROUTER ######
// -------------------------------------------------- Router functions:
Router::Router(SimulatedMachine* sm){
    my_friend = sm;
    pthread_mutex_init(&(this->router_lock), NULL);
    
    server_size = my_friend->serverNum;
    FOR(i,server_size){
        learn[i].nextHopRtt = cur[i].nextHopRtt = my_friend->gatewayIp;
        learn[i].nextHopLoss = cur[i].nextHopLoss = my_friend->gatewayIp;
        mac_copy( &(learn[i].rtt_mac), &(my_friend->gatewayMac) );
        mac_copy( &(learn[i].loss_mac), &(my_friend->gatewayMac) );
        mac_copy( &(cur[i].rtt_mac), &(my_friend->gatewayMac) );
        mac_copy( &(learn[i].loss_mac), &(my_friend->gatewayMac) );
    }
}

void Router::Reset(){
    pthread_mutex_lock(&(this->router_lock));
    
    // saving learn table
    FOR(i,server_size){
        cur[i].iface_l = learn[i].iface_l;
        cur[i].iface_r = learn[i].iface_r;
        
        cur[i].nextHopRtt = learn[i].nextHopRtt;
        cur[i].nextHopLoss = learn[i].nextHopLoss;
        
        mac_copy( &(cur[i].loss_mac), &(learn[i].loss_mac));
        mac_copy( &(cur[i].rtt_mac), &(learn[i].rtt_mac));
    }
    
    // re-initializing learn table
    FOR(i,server_size){
        learn[i].iface_l = learn[i].iface_r = 1;
        learn[i].nextHopRtt = learn[i].nextHopLoss = my_friend->gatewayIp;
        mac_copy( &(learn[i].rtt_mac), &(my_friend->gatewayMac) );
        mac_copy( &(learn[i].loss_mac), &(my_friend->gatewayMac) );
        learn[i].rtt = my_friend->server_list[i].getRtt();
        learn[i].loss_rate = my_friend->server_list[i].lossRate();
    }
    
    pthread_mutex_unlock(&(this->router_lock));
    return;
}

void Router::rtt_update(uint32_t idx_ifc, mac_addr* m_source, uint32_t ip_source, uint32_t new_rtt){
    uint32_t idx = idx_ifc >> 4;
    uint32_t new_ifc = idx_ifc & 0x0f;
    
    if( (new_ifc == 1 && learn[idx].iface_r == 1) || (new_rtt < learn[idx].rtt) ){
        learn[idx].rtt = new_rtt;
        learn[idx].iface_r = new_ifc;
        learn[idx].nextHopRtt = ip_source;
        mac_copy(&(learn[idx].rtt_mac), m_source);
    }
    return;
}

void Router::loss_update(uint32_t idx_ifc, mac_addr* m_source, uint32_t ip_source, double new_loss){
    uint32_t idx = idx_ifc >> 4;
    uint32_t new_ifc = idx_ifc & 0x0f;
    
    if( (new_ifc == 1 && learn[idx].iface_l == 1) || (new_loss < learn[idx].loss_rate) ){
        learn[idx].loss_rate = new_loss;
        learn[idx].iface_l = new_ifc;
        learn[idx].nextHopLoss = ip_source;
        mac_copy(&(learn[idx].loss_mac), m_source);
    }
    return;
}

void Router::remove_related(uint32_t peer_ip){
    FOR(i, server_size){
        if( learn[i].nextHopRtt == peer_ip ){
            learn[i].iface_r = 1;
            learn[i].nextHopRtt = my_friend->gatewayIp;
            mac_copy( &(learn[i].rtt_mac), &(my_friend->gatewayMac) );
            learn[i].rtt = my_friend->server_list[i].getRtt();
        }
        if( learn[i].nextHopLoss == peer_ip ){
            learn[i].iface_l = 1;
            learn[i].nextHopLoss = my_friend->gatewayIp;
            mac_copy( &(learn[i].loss_mac), &(my_friend->gatewayMac) );
            learn[i].loss_rate = my_friend->server_list[i].lossRate();
        }
    }
    return;
}

// ###### SIMULATE MACHIEN ######
// -------------------------------------------------- Basic functions:

int SimulatedMachine::convert1(char a){// convert hexadecimal char->int
    if ('0' <= a && a <= '9')
        return a - '0';
    else
        return a - 'A' + 10;
}

string SimulatedMachine::write_ip(uint32_t ip){
    stringstream ss;
    string result;
    ss<<PRINTIP(ip);
    ss>>result;
    return result;
}

void SimulatedMachine::read_mac(string src, mac_addr* ptr){
    uint32_t size = ETHER_ADDR_LEN;
    FOR(i,size)
        ptr->data[i] = convert1(src[i*3])*16 + convert1(src[i*3 + 1]);
    return;
}

uint32_t SimulatedMachine::read_ip(string str){
    str += ".";
    uint32_t ip = 0;
    stringstream ss(str);
    int tmp;
    char c;
    FOR(i,4){
        ss>>tmp>>c;
        ip = (ip<<8) + tmp;
    }
    return ip;
}
// -------------------------------------------------- Tables and Database functions:
uint32_t SimulatedMachine::findIndex_byIp(uint32_t ip_var){
    FOR(i, serverNum)
        if( ip_var == this->server_list[i].server_ip)
            return i;
    return MAX_SERVER + 1;
}

// -------------------------------------------------- Peers functions:
bool SimulatedMachine::find_mac_byIp(uint32_t s_ip, mac_addr* mac_dst){
    FOR(i, mac_ip_size)
    if( s_ip ==  im_table[i].IP){
        mac_copy(mac_dst, &(im_table[i].MAC));
        return true;
    }
    return false;
}
uint32_t SimulatedMachine::find_ip_byMac(mac_addr* s_mac){
    FOR(i, mac_ip_size)
    if( mac_compare(s_mac, &(im_table[i].MAC)) )
        return im_table[i].IP;
    return INFINITY;
}

void SimulatedMachine::insert_peer(uint32_t p_ip, mac_addr* p_mac){
    mac_addr tmp;
    if(find_mac_byIp(p_ip, &tmp) )
        return;
    im_table[mac_ip_size].IP = p_ip;
    mac_copy( &(im_table[mac_ip_size++].MAC), p_mac );
    return;
}

SimulatedMachine::SimulatedMachine (const ClientFramework *cf, int count) :
	Machine (cf, count) {
	// The machine instantiated.
	// Interfaces are not valid at this point.
}

SimulatedMachine::~SimulatedMachine () {
	// destructor...
}

void SimulatedMachine::initialize () {
	// TODO: Initialize your program here; interfaces are valid now.
    FOR(j,IFACE_NUM)
        my_ip[j] = this->iface[j].getIp();
    
    FOR(i,IFACE_NUM)
        FOR(j,ETHER_ADDR_LEN)
            my_macs[i].data[j] = iface[i].mac[j];
    
    pthread_mutex_init(&(this->server_db_lock), NULL);
    pthread_mutex_init(&(this->port_lock), NULL);
    
#ifdef DBG_MOD
    cerr<<"my ips: "<<write_ip(my_ip[0])<<" "<<write_ip( my_ip[1] )<<endl;
#endif
    last_app_port = 8000;
    
    // reading custom information
    string tmp;
    string info = getCustomInformation();
    stringstream ss(info);
    
    ss>>tmp;
    this->gatewayIp = read_ip(tmp);
    ss>>tmp;
    read_mac(tmp, &(this->gatewayMac));
    ss>>serverNum;
    FOR(i,serverNum){
        ss>>tmp;
        server_list[i].server_ip = read_ip(tmp);
    }
    
    // peers:
    step = 0;
    mac_ip_size = 0;
    router = new Router(this);
    
    return;
}


/**
 * This method is called from the main thread.
 * Also ownership of the data of the frame is not with you.
 * If you need it, make a copy for yourself.
 *
 * You can also send frames using:
 * <code>
 *     bool synchronized sendFrame (Frame frame, int ifaceIndex) const;
 * </code>
 * which accepts one frame and the interface index (counting from 0) and
 * sends the frame on that interface.
 * The Frame class used here, encapsulates any kind of network frame.
 * <code>
 *     class Frame {
 *     public:
 *       uint32 length;
 *       byte *data;
 *
 *       Frame (uint32 _length, byte *_data);
 *       virtual ~Frame ();
 *     };
 * </code>
 */
void SimulatedMachine::processFrame (Frame frame, int ifaceIndex) {
	// TODO: process the raw frame; frame.data points to the frame's byte stream
#ifdef DBG_MOD
    cerr<< "Frame received at iface " << ifaceIndex <<
    " with length " << frame.length << endl;
    FOR(i, frame.length){
        if( i==sizeof(sr_ethernet_hdr) || i==(sizeof(sr_ethernet_hdr) + sizeof(ip)) )
            cerr<<"\n";
        
        if( i< sizeof(sr_ethernet_hdr))
            cerr<<std::hex<<(int)frame.data[i]<<" ";
        else
            cerr<<std::dec<<(int)frame.data[i]<<" ";
    }
    cerr<<"\n";
#endif
    try {
        message msg(this, ifaceIndex, &frame);
        custom_msg_header TMP;
        
        if( msg.tl.type == 0 ){// advertise
            uint32_t sindex;
            sr_broadcast* adv_msg = msg.tl.server_nodes;
            mac_addr* adv_src_mac = &(msg.tl.src_mac);
            uint32_t adv_src_ip = msg.tl.sender.ip;
            
            pthread_mutex_lock( &(router->router_lock) );
            // Critical section for router database:
            // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            router->remove_related(msg.tl.sender.ip);
            FOR(s,msg.tl.adv_num){
                sindex = findIndex_byIp( adv_msg[s].server_ip );
                if( sindex >= MAX_SERVER )
                    continue;
                
                double new_loss = 1.0 - ((double) adv_msg[s].rcv_cnt)/((double)adv_msg[s].sent_cnt);
                router->loss_update( (sindex<<4)+(uint32_t)ifaceIndex, adv_src_mac, adv_src_ip, new_loss);
                router->rtt_update( (sindex<<4)+(uint32_t)ifaceIndex, adv_src_mac, adv_src_ip, adv_msg[s].RTT);
            }
            // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            pthread_mutex_unlock( &(router->router_lock) );
            return;
            
        }else if( msg.tl.type == 1 ){// application
            
            if( msg.tl.reciever.ip == my_ip[1] ){// [1] -- sent for me:
                
                // SEARCH IN NAT:
                pthread_mutex_lock( &(nat.nat_lock) );
                
                int idx = nat.findIndexbyPort( msg.tl.reciever.port );
                if( idx>=0 ){//NAT:
                    TMP.type = 1;
                    TMP.reciever.ip = nat.table[idx].main_ip;
                    TMP.sender.ip = msg.tl.sender.ip;
                    
                    TMP.reciever.port = nat.table[idx].main_port;
                    TMP.sender.port = msg.tl.sender.port;
                    mac_copy( &(TMP.dst_mac), &(nat.table[idx].main_mac) );
                    message app_forward(this, 0, &TMP);
                    sendFrame( app_forward.generate_frame(), 0 );
                    
                    if( msg.tl.sender.port == 1000 )
                        cout<<"DSA ";
                    else
                        cout<<"LSA ";
                    
                    cout<<"forwarded packet reply received from "<<write_ip( msg.tl.sender.ip )<<endl;
                    nat.remove_index(idx);
                    pthread_mutex_unlock( &(nat.nat_lock) );
                    return;
                }
                pthread_mutex_unlock( &(nat.nat_lock) );
                
                // SEARCH IN APP STACK:
                pthread_mutex_lock( &(app_stack.app_stack_lock) );
                idx = app_stack.findIndexbyPort( msg.tl.reciever.port );
                if( idx<0 ){
                    pthread_mutex_unlock( &(app_stack.app_stack_lock) );
                    return;
                }
                
                chrono::time_point< chrono::system_clock > here;
                here = chrono::system_clock::now();
                chrono::duration<double> elapsed_seconds = here - app_stack.table[idx].app_try;
                app_stack.remove_index( idx );
                pthread_mutex_unlock( &(app_stack.app_stack_lock) );
                
                uint32_t delay = (uint32_t)( 1000.0 * (double)elapsed_seconds.count());
                
                if( msg.tl.sender.port == 1000 )
                    cout<<"DSA ";
                else
                    cout<<"LSA ";
                cout<<"packet "<<msg.tl.reciever.port<<" reply received in "<<delay<<"ms\n";
                return;
                
            }else{// [1] -- didn't send for me:
                
                pthread_mutex_lock( &(nat.nat_lock) );
                // Critical section for NAT database:
                // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                int idx = nat.top;
                
                nat.table[idx].main_ip = msg.tl.sender.ip;
                nat.table[idx].main_port = msg.tl.sender.port;
                mac_copy( &(nat.table[idx].main_mac), &(msg.tl.src_mac) );
                
                pthread_mutex_lock( &(this->port_lock) );
                nat.table[idx].my_port = last_app_port++;
                pthread_mutex_unlock( &(this->port_lock) );
                
                TMP.type = 1;
                TMP.sender.ip = my_ip[1];
                TMP.reciever.ip = msg.tl.reciever.ip;
                
                TMP.reciever.port = msg.tl.reciever.port;
                TMP.sender.port = nat.table[idx].my_port;
                nat.top++;
                
                message forwarded(this, 1, &TMP);
                sendFrame( forwarded.generate_frame(), 1);
                
                if( TMP.reciever.port == 1000 )
                    cout<<"DSA ";
                else
                    cout<<"LSA ";
                cout<<"packet forwarded to "<<write_ip( TMP.reciever.ip )<<endl;
                
                // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                pthread_mutex_unlock( &(nat.nat_lock) );
                return;
            }
            
        }else{// ICMP
            if( msg.tl.icmp_type == 0 ){// icmp reply
                
                pthread_mutex_lock(&(this->server_db_lock));
                // Critical section for server database:
                // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                uint32_t index = findIndex_byIp(msg.tl.sender.ip);
                if( index >= MAX_SERVER )
                    throw 12;
                #ifdef DBG_MOD
                cerr<< "::icmp reply from "<<write_ip(msg.tl.sender.ip)<<" : seq_num = "<<msg.tl.sequenceNumber<<endl;
                #endif
                if( msg.tl.sequenceNumber < server_list[index].seq )
                    return; // drop
                server_list[index].update();
                // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                pthread_mutex_unlock(&(this->server_db_lock));
                
                pthread_mutex_lock( &(router->router_lock) );
                
                router->loss_update((index<<4)+(uint32_t)ifaceIndex, &gatewayMac, gatewayIp, server_list[index].lossRate());
                router->rtt_update((index<<4)+(uint32_t)ifaceIndex, &gatewayMac, gatewayIp, server_list[index].getRtt());
                
                pthread_mutex_unlock( &(router->router_lock) );
                
            }else{// icmp request
                TMP.type = 2;
                TMP.icmp_type = 0;
                
                TMP.reciever.ip = msg.tl.sender.ip;
                TMP.sender.ip = my_ip[1];
                TMP.sequenceNumber = msg.tl.sequenceNumber;
                
                message icmp_message(this, 1, &TMP);
                sendFrame(icmp_message.generate_frame(), 1);
            }
        }
    } catch (int ex) {
#ifdef DBG_MOD
        cerr<< "::ERROR: exception("<<ex<<") occured because of header error!\n"<<endl;
#endif
        return;
    }
    return;
}


/**
 * This method will be run from an independent thread. Use it if needed or simply return.
 * Returning from this method will not finish the execution of the program.
 */
void SimulatedMachine::run () {
	// TODO: write your business logic here...
    string cmd(20,0);
    custom_msg_header TMP;
    
    while(true){
        
        step++;
        if( step%128 == 127 )
            cmd = "test";
        else
            cin>>cmd;
        
        if(cmd == "ping"){
            TMP.type = 2;
            TMP.icmp_type = 8;
            TMP.sender.ip = my_ip[1];
            
            pthread_mutex_lock(&(this->server_db_lock));
            // Critical section for server database:
            // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            FOR(s,serverNum){
                server_list[s].send_increament();
                TMP.reciever.ip = server_list[s].server_ip;
                TMP.sequenceNumber = (uint16_t) server_list[s].seq;
                message icmp_message(this, 1, &TMP);
                sendFrame(icmp_message.generate_frame(), 1);
            }
            // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            // end of critical section
            pthread_mutex_unlock(&(this->server_db_lock));
        }else if(cmd == "stats" ){
            FOR(s,serverNum){
                cout<<write_ip(server_list[s].server_ip)<<" ";
                if( server_list[s].isConnected() )
                    cout<<server_list[s].getRtt()<<" "<<fixed<<setprecision(2)<<server_list[s].lossRate()<<" ("
                    <<server_list[s].sent<<" "<<server_list[s].received<<")\n";
                else
                    cout<<"INF 1.00"<<endl;
            }
        }else if(cmd == "advertise"){
            uint32_t idx;
            TMP.type = 0;
            TMP.sender.ip = my_ip[0];
            TMP.sender.port = broadcast_port;
            TMP.reciever.port = broadcast_port;
            FOR(i,serverNum)
                if( server_list[i].isConnected() ){
                    idx = TMP.adv_num;
                    TMP.server_nodes[idx].server_ip = server_list[i].server_ip;
                    TMP.server_nodes[idx].RTT = server_list[i].getRtt();
                    TMP.server_nodes[idx].sent_cnt = server_list[i].sent;
                    TMP.server_nodes[idx].rcv_cnt = server_list[i].received;
                    TMP.adv_num++;
                }
            
            message broadcast_message(this, 0, &TMP);
            if( sendFrame(broadcast_message.generate_frame(), 0) == false){
            #ifdef DBG_MOD
                cerr<<":: partov send function failed!"<<endl;
            #endif
            }
            router->Reset();
            #ifdef DBG_MOD
                cerr<<"++++++ advertisement completed"<<endl;
            #endif
            
        }else if(cmd == "dtable" ){
            pthread_mutex_lock( &(router->router_lock) );
            FOR(i,serverNum){
                cout<<write_ip( server_list[i].server_ip )<<" ";
                cout<<write_ip( router->cur[i].nextHopRtt )<<" ";
                cout<<write_ip( router->learn[i].nextHopRtt )<<" ";
                if( (router->learn[i].iface_r == 1) && server_list[i].isConnected() == false )
                    cout<<"INF\n";
                else
                    cout<<router->learn[i].rtt<<endl;
            }
            pthread_mutex_unlock( &(router->router_lock) );
            
        }else if(cmd == "ltable" ){
            pthread_mutex_lock( &(router->router_lock) );
            FOR(i,serverNum){
                cout<<write_ip( server_list[i].server_ip )<<" ";
                cout<<write_ip( router->cur[i].nextHopLoss )<<" ";
                cout<<write_ip( router->learn[i].nextHopLoss )<<" ";
                if( (router->learn[i].iface_l == 1) && server_list[i].isConnected() == false )
                    cout<<"1.00\n";
                else
                    cout<<fixed<<setprecision(2)<<router->learn[i].loss_rate<<endl;
            }
            pthread_mutex_unlock( &(router->router_lock) );
            
        }else if(cmd == "lsa" ){
            cin>>cmd;
            uint32_t lsa_server_ip = read_ip(cmd);
            uint32_t idx = findIndex_byIp(lsa_server_ip);
            if( idx >= MAX_SERVER )
                continue;
            
            TMP.type = 1;
            TMP.sender.ip = my_ip[1];
            TMP.reciever.ip = lsa_server_ip;
            TMP.reciever.port = 2000;
            
            pthread_mutex_lock( &(this->port_lock) );
            TMP.sender.port = last_app_port++;
            pthread_mutex_unlock( &(this->port_lock) );
            
            pthread_mutex_lock( &(router->router_lock) );
            uint32_t interface = router->cur[idx].iface_l;
            mac_copy(&(TMP.dst_mac), &(router->cur[idx].loss_mac));
            
            cout<<"LSA packet "<<TMP.sender.port<<" destined for "<<write_ip(lsa_server_ip)
                <<" sent to "<<write_ip(router->cur[idx].nextHopLoss)<<endl;
            pthread_mutex_unlock( &(router->router_lock) );
            
            message lsa_msg(this, interface, &TMP);
            lsa_msg.generate_frame();
            
            // insert information to app stack:
            pthread_mutex_lock( &(app_stack.app_stack_lock));
            app_stack.table[ app_stack.top ].port = TMP.sender.port;
            app_stack.table[ app_stack.top ].app_try = chrono::system_clock::now();
            app_stack.top++;
            pthread_mutex_unlock( &(app_stack.app_stack_lock));
        
            sendFrame(lsa_msg.forward_to_mac( &(TMP.dst_mac), interface), interface);
            std::this_thread::sleep_for (std::chrono::milliseconds(2500));
            
        }else if(cmd == "dsa" ){
            cin>>cmd;
            uint32_t lsa_server_ip = read_ip(cmd);
            uint32_t idx = findIndex_byIp(lsa_server_ip);
            if( idx >= MAX_SERVER )
                continue;
            
            TMP.type = 1;
            TMP.sender.ip = my_ip[1];
            TMP.reciever.ip = lsa_server_ip;
            TMP.reciever.port = 1000;
            
            pthread_mutex_lock( &(this->port_lock) );
            TMP.sender.port = last_app_port++;
            pthread_mutex_unlock( &(this->port_lock) );
            
            pthread_mutex_lock( &(router->router_lock) );
            uint32_t interface = router->cur[idx].iface_r;
            mac_copy(&(TMP.dst_mac), &(router->cur[idx].rtt_mac));
            
            cout<<"DSA packet "<<TMP.sender.port<<" destined for "<<write_ip(lsa_server_ip)
                <<" sent to "<<write_ip(router->cur[idx].nextHopRtt)<<endl;
            pthread_mutex_unlock( &(router->router_lock) );
            
            message lsa_msg(this, interface, &TMP);
            lsa_msg.generate_frame();
            
            // insert information to app stack:
            pthread_mutex_lock( &(app_stack.app_stack_lock));
            app_stack.table[ app_stack.top ].port = TMP.sender.port;
            app_stack.table[ app_stack.top ].app_try = chrono::system_clock::now();
            app_stack.top++;
            pthread_mutex_unlock( &(app_stack.app_stack_lock));
            
            sendFrame(lsa_msg.forward_to_mac( &(TMP.dst_mac), interface), interface);
            std::this_thread::sleep_for (std::chrono::milliseconds(2500));
            
        }else if(cmd == "test" ){
            if( app_stack.top >= NAT_SIZE)
                app_stack.top = 0;// reset app stack manually
            if( nat.top >= NAT_SIZE )
                nat.top = 0;// reset app stack manually
        #ifdef DBG_MOD
            cerr<<"------------< TEST >-------------\n";
            cerr<<"nat size = "<<nat.top<<endl;
            cerr<<"app stack size = "<<app_stack.top<<endl;
            cerr<<"last used port = "<<last_app_port<<endl;
            cerr<<"---------------------------------\n";
        #endif
        
        }
    }
}


/**
 * You could ignore this method if you are not interested on custom arguments.
 */
void SimulatedMachine::parseArguments (int argc, char *argv[]) {
	// TODO: parse arguments which are passed via --args
}

