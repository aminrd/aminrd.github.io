//                   In the name of GOD
/**
 * Partov is a simulation engine, supporting emulation as well,
 * making it possible to create virtual networks.
 *  
 * Copyright © 2009-2014 Behnam Momeni.
 * 
 * This file is part of the Partov.
 * 
 * Partov is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Partov is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Partov.  If not, see <http://www.gnu.org/licenses/>.
 *  
 * =====================================================================
 * == Mohammad Amin Aghaee Rad -- 90105634                            ==
 * == Course: Computer Networks                                       ==
 * == Programming assignment2                                         ==
 * =====================================================================
 */

#ifndef _S_M_H_
#define _S_M_H_

#include "machine.h"
#include "frame.h"
#include "sr_protocol.h"

#include <string>
#include <vector>
#include <pthread.h>
#include <time.h>
#include <chrono>
using namespace std;


//--------------------Basic definitions:
//#define DBG_MOD
#define MAX_SERVER 16
#define MAX_PEER 32
#define IFACE_NUM 2
#define BUFFER_SIZE 256
#define NAT_SIZE 128
#define INFINITY 0xffffffff

#ifndef FOR
#define FOR(i,x) for(uint32_t i=0; i<(x); i++)
#endif
//--------------------------------------


struct mac_addr{
    uint8_t data[ETHER_ADDR_LEN];
};
struct client_info{
    uint32_t ip;
    uint16_t port;
};
struct ip_mac_pair{
    mac_addr MAC;
    uint32_t IP;
};
struct custom_msg_header{
    custom_msg_header(){
        adv_num = 0;
    }
    uint8_t type; /*
                 UDP(advertise):0, 
                 UDP(application):1, 
                 ICMP:2 
                 */
    mac_addr src_mac, dst_mac;
    client_info sender, reciever;
    
    //UDP(advertise):
    sr_broadcast server_nodes[MAX_SERVER];
    uint32_t adv_num;
    
    //ICMP:
    uint16_t sequenceNumber;
    uint8_t icmp_type; // request(8), reply(0)
};
struct Rout_info{
    Rout_info(){
        rtt = INFINITY;
        loss_rate = 1.00;
        iface_l = iface_r = 1;
    }
    uint32_t iface_r, iface_l;
    uint32_t nextHopRtt, nextHopLoss;
    mac_addr rtt_mac, loss_mac;
    
    uint32_t rtt;
    double loss_rate;
};

void mac_copy(mac_addr* , mac_addr*);
bool mac_compare(mac_addr* , mac_addr*);
uint16_t calculateIPCheckSum(ip *);
uint16_t calculateIcmpCheckSum(sr_icmp *);
bool simulate_timeout(bool* flag, int max);

// SERVER INFO:
struct serverInfo{
    serverInfo(){
        memory = 0;
        seq = -1;
        sent = received = 0;
    }
    
    int memory;
    uint32_t server_ip;
    short seq;
    uint32_t rtt;
    uint16_t sent, received;
    chrono::time_point< chrono::system_clock > last_try;
    
    // functions:
    bool isConnected() const{
        if( (memory & 0x07 ) == 0)
            return false;
        return true;
    }
    double lossRate() const{
        if( !isConnected())
            return 1.00;
        return 1.00 - ((double) received)/((double)sent);
    }
    uint32_t getRtt(){
        if( isConnected() )
            return rtt;
        return INFINITY;
    }
    void send_increament(){
        memory = memory << 1;
        seq++;
        if(isConnected())
            sent ++;
        last_try = chrono::system_clock::now();
    }
    void update(){
        chrono::time_point< chrono::system_clock > rcv_time;
        rcv_time = chrono::system_clock::now();
        chrono::duration<double> elapsed_seconds = rcv_time - last_try;
        uint32_t new_rtt = (uint32_t)(1000.0 * (double)elapsed_seconds.count());
        
        if( isConnected())
            rtt = (rtt + new_rtt)>>1;
        else{
            ++sent;
            rtt = new_rtt;
        }
        ++received;
        memory = memory | 1;
    }
};

// Message:
class SimulatedMachine;// forward declaration
struct message{
    // message functions and constructors;
    message(SimulatedMachine* my_friend, int Iface_num, custom_msg_header* TH);
    message(SimulatedMachine* my_friend, int Iface_num, Frame* input_frame);
    Frame generate_frame();
    Frame forward_to_mac(mac_addr* f_mac, uint32_t ifc);
    
    // message variables:
    SimulatedMachine* main_machine;
    short iface_num;
    custom_msg_header tl;
    
    mac_addr src_mac, dst_mac;
    uint8_t buffer[BUFFER_SIZE];
    uint32_t buffer_size;
//    Frame* test_frame;
    
    // destructor:
    ~message(){
//        delete test_frame;
    }
};

// Router:
struct Router{
    // functions:
    Router(SimulatedMachine* sm);
    void Reset();
    
    void rtt_update(uint32_t idx_ifc, mac_addr* m_source, uint32_t ip_source, uint32_t new_rtt);
    void loss_update(uint32_t idx_ifc, mac_addr* m_source, uint32_t ip_source, double new_loss);
    void remove_related(uint32_t peer_ip);
    
    // variables:
    SimulatedMachine* my_friend;
    pthread_mutex_t router_lock;
    
    uint32_t server_size;
    Rout_info learn[MAX_SERVER];
    Rout_info cur[MAX_SERVER];
};

// NAT:
struct NAT{
    // functions:
    NAT(){
        top = 0;
        pthread_mutex_init( &(this->nat_lock),NULL );
    }
    int findIndexbyPort( uint16_t s_port ){
        FOR(i, top)
            if( s_port == table[i].my_port )
                return (int) i;
        return -1;
    }
    void remove_index (int index){
        top--;
        if( (uint32_t)index == top )
            return;
        memcpy( (void*)&(table[index]), (void*)&(table[top]), sizeof(table[0]) );
    }
    //variables:
    pthread_mutex_t nat_lock;
    uint32_t top;
    
    struct{
        uint16_t my_port, main_port;
        uint32_t main_ip;
        mac_addr main_mac;
    }table[NAT_SIZE];
};

// APP STACK:
struct APP_STACK{
    APP_STACK(){
        this->top = 0;
        pthread_mutex_init( &(this->app_stack_lock),NULL );
    }
    int findIndexbyPort( uint16_t s_port ){
        FOR(i, top)
            if( s_port == table[i].port )
                return (int) i;
        return -1;
    }
    void remove_index (int index){
        top--;
        if( (uint32_t)index == top )
            return;
        table[index].port = table[top].port;
        table[index].app_try = table[top].app_try;
    }
    
    // variables:
    uint32_t top;
    pthread_mutex_t app_stack_lock;
    struct{
        uint16_t port;
        chrono::time_point< chrono::system_clock > app_try;
    } table[NAT_SIZE];
};


// SimulatedMachine :
class SimulatedMachine : public Machine {
public:
    friend struct message;
    friend struct Router;
    
	SimulatedMachine (const ClientFramework *cf, int count);
	virtual ~SimulatedMachine ();

	virtual void initialize ();
	virtual void run ();
	virtual void processFrame (Frame frame, int ifaceIndex);
	
	static void parseArguments (int argc, char *argv[]);
    
    // Basic functions:
    int convert1(char a);
    void read_mac(string src, mac_addr* ptr);
    string write_ip(uint32_t ip);
    uint32_t read_ip(string str);
    
    // Tables and Database functions:
    uint32_t findIndex_byIp(uint32_t ip_var);
    
    // Peers functions:
    bool find_mac_byIp(uint32_t s_ip, mac_addr* mac_dst);
    uint32_t find_ip_byMac(mac_addr* s_mac);
    void insert_peer(uint32_t p_ip, mac_addr* p_mac);
    
    // Variables:
    mac_addr gatewayMac;
    uint32_t gatewayIp;
    
    uint16_t last_app_port;
    pthread_mutex_t port_lock;
    
    mac_addr my_macs[IFACE_NUM];
    uint32_t my_ip[IFACE_NUM];
    
    uint32_t serverNum,step;
    pthread_mutex_t server_db_lock;
    serverInfo server_list[MAX_SERVER];
    
    // peers :
    uint32_t mac_ip_size;
    ip_mac_pair im_table[MAX_PEER];
    
    // Routing :
    Router* router;
    NAT nat;
    APP_STACK app_stack;
    
};

#endif /* sm.h */

