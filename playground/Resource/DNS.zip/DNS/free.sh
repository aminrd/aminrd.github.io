source info.sh
./ron.out --ip $ip --port $port --map $map --user $user --pass "$pass" --free
