user=90105634
pass=partovpassamin
map=ron
node=client-0
ip=213.233.169.80
port=7890
