/*
 * File name: 
 * acc_structure.h	
 * Description:  
 * Accounts management class
 * -------------------------------------------------
 * HSM ( version 3 )
 * Beagle Bone Black secure machine
 * kernel : Debian
 * by : 
 *		Amin Aghaee
 *		Superviros: Dr. Siavash Bayat-Sarmadi
 * Sharif University of Technology
 * Computer engineering department
 * All rights reserved(2016)
 * -------------------------------------------------
*/
#ifndef _ACC_SCTRUCTURE_h
#define _ACC_SCTRUCTURE_h

struct ACC{
	string username;
	string password;
	string pth2_dir;
};

struct acc_db{
	// variables:
	vector <ACC> users;
	string db_dir;
	
	// functions:
	acc_db(){
		db_dir = pth2_acc + "acc_list.txt";
		ifstream fin(db_dir.c_str());
		ACC tmp;
		string a;
		while(fin>>a){
			tmp.username = a;
			fin>>tmp.password;
			fin>>tmp.pth2_dir;
			users.push_back(tmp);
		}
		fin.close();
	}
	int get_user_number(){
		return users.size();
	}
	int find_username(string username){
		FOR(i,users.size())
			if(users[i].username == username)
				return i;
		return -1;	
	}
	
	void update_db(int mode){
		// mode: 0->save all data, 1->update with the top new data
		ofstream fout;
		if(mode==0){
			fout.open (this->db_dir.c_str(), std::ofstream::out | std::ofstream::trunc);
			FOR(i,users.size())
				fout<<users[i].username<<" "<<users[i].password<<" "<<users[i].pth2_dir<<"\n";
			fout.close();			
		}else{
			fout.open (this->db_dir.c_str(), std::ofstream::out | std::ofstream::app);
			int idx = this->users.size() - 1;
			fout<<users[idx].username<<" "<<users[idx].password<<" "<<users[idx].pth2_dir<<"\n";
			fout.close();
		}
		return;
	}
	
	string login(string a, string b){
		FOR(i,users.size())
			if(users[i].username == a && users[i].password == b)
				return users[i].pth2_dir;
		return "-1";
	}
	bool create_new(ACC n_user){
		if( find_username(n_user.username) >= 0 )	
			return false;
		
		srand (time(NULL));
		int rnd = rand();
		char crnd[20];
		sprintf(crnd,"%d",rnd);
		string srnd = crnd;
		n_user.pth2_dir = md5(n_user.username + n_user.password + srnd);
		this->users.push_back(n_user);
		update_db(0);
		char cmd[200];
		#ifdef _WIN32
			sprintf(cmd,"mkdir %s > NUL",n_user.pth2_dir.c_str());	
			system(cmd);
			sprintf(cmd,"move %s %s > NUL",n_user.pth2_dir.c_str(),pth2_acc.c_str());	
			system(cmd);
		#else
			string _mypath = pth2_acc + n_user.pth2_dir;
			sprintf(cmd,"mkdir -p %s",_mypath.c_str());			
			system(cmd);
		#endif	
		return true;
	}
	bool delete_acc(int index){
		if(index<0 || index >=this->users.size()) return false;
		char cmd[200];
		string _mypath = pth2_acc + users[index].pth2_dir;
		#ifdef _WIN32			
			sprintf(cmd,"move %s %s > NUL",_mypath.c_str(),pth2_acc.c_str());				
			system(cmd);
			sprintf(cmd,"rmdir %s > NUL",users[index].pth2_dir.c_str());	
			system(cmd);
		#else			
			sprintf(cmd,"rm -rf %s &> /dev/null",_mypath.c_str());			
			system(cmd);
		#endif					
		int top = this->users.size() - 1;
		users[index].username = users[top].username;
		users[index].password = users[top].password;
		users[index].pth2_dir = users[top].pth2_dir;
		this->users.pop_back();		
		update_db(0);
		return true;
	}
	bool delete_by_username(string username){
		int idx = find_username(username);
		if(idx<0) return false;
		return delete_acc(idx);
	}
	void change_password(int idx, string new_pass){
		this->users[idx].password = new_pass;
		update_db(0);
		return;
	}
	bool change_pass_user(string username, string new_pass){
		int idx = find_username(username);
		if(idx<0) return false;
		change_password(idx, new_pass);
		return true;
	}
};

#endif
