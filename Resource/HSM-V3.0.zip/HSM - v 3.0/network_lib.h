/*
 * File name:
 * network_lib.h
 * Description:
 * Network Common functions
 * -------------------------------------------------
 * HSM ( version 3 )
 * Beagle Bone Black secure machine
 * kernel : Debian
 * by :
 *		Amin Aghaee
 *		Superviros: Dr. Siavash Bayat-Sarmadi
 * Sharif University of Technology
 * Computer engineering department
 * All rights reserved(2016)
 * -------------------------------------------------
 
 */
#ifndef _NETWORK_LIB_H
#define _NETWORK_LIB_H

#include <iostream>
#include <sstream>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include <string.h>
#include <cstdint>
#include <sys/socket.h>

using namespace std;

#ifndef FOR
#define FOR(i,x) for(int i=0;i<(x);i++)
#endif

#ifndef HSM_BUF_SIZE
#define HSM_BUF_SIZE 512
#endif

// --------------------------------------
int sock_fd;
uint8_t buffer1[HSM_BUF_SIZE]; // Sending Buffer
uint8_t buffer2[HSM_BUF_SIZE]; // Recieving Buffer
string user_path, base_path;

// --------------------------------------
uint8_t mask = 0x7F;
uint8_t smask = 0x00;
uint8_t cmask = 0x80;
uint8_t msg_header;
uint8_t _F1 = 0xFF;
// --------------------------------------


void make_dir(string);
void make_dir(string _mypath){
    char cmd[200];
    sprintf(cmd,"mkdir -p %s",_mypath.c_str());
    system(cmd);
    return;
}

void print_buf( uint8_t* );
void print_buf( uint8_t* bufname){
    cerr<<"\n -------------------------------------\n";
    cout<<(int)bufname[0] << "- ";
    string tmp = (char*) bufname + 1;
    cout<<tmp<<endl;
    return;
}

void cpy2buf(uint8_t*, string, int);
void cpy2buf(uint8_t* bufname, string msg, int start){
    FOR(i, msg.size() + 1)
        bufname[i+start] = msg[i];
    return;
}


vector<string> getstrings( uint8_t* );
vector<string> getstrings( uint8_t* buf ){
    istringstream iss((char*)buf);
    string tmp;
    vector<string> list;
    while( iss>>tmp ){
        list.push_back(tmp);
    }
    return list;
}

void setbuf_2byte(uint8_t*, int, uint8_t);
void setbuf_2byte(uint8_t* bufname, int index, uint8_t my_byte){
    for(int i=index; i<HSM_BUF_SIZE; i++)
        bufname[i] = my_byte;
    return;
}

int find_first_my_byte(uint8_t*, uint8_t); // breaking byte
int find_first_my_byte(uint8_t* bufname, uint8_t my_byte){
    int index = HSM_BUF_SIZE-1;
    while( bufname[index] == my_byte ) index--;
    return index+1;
}

void cpybuf_2char(char*, uint8_t*, int);
void cpybuf_2char(char* dest, uint8_t* src, int index){
    for(int i=index; i<HSM_BUF_SIZE; i++)
        dest[i-index] = src[i];
    return;
}

int my_send(int);
int my_send(int size = HSM_BUF_SIZE){
    int sock_add = sock_fd;
    int sent_b = send(sock_add, (void*) buffer1, size * sizeof(uint8_t), 0);
    if(sent_b <0 ){
        cerr<<"couldn't combine and send the packet from the client"<<endl;
        return -1;
    }
//    print_buf(buffer1);
    return 0;
}

int my_rcv(int);
int my_rcv(int size = HSM_BUF_SIZE){
    int sock_add= sock_fd;
    int sent_b = recv(sock_add, (void*) buffer2, size * sizeof(uint8_t), 0);
    if(sent_b <0 ){
        cerr<<"couldn't recieve and braek the packet from the server -%cli-rcv-brk-1"<<endl;
        return -1;
    }
//    print_buf(buffer2);
    return 0;
}


enum ServerResult
{
	SERVER_SUCCESSFULL,
	SERVER_SOCKET_RES_ERROR,
	SERVER_BIND_ERROR,
	SERVER_LISTEN_ERROR
};

uint32_t char_to_int(char* input){
    uint32_t number = 0;
    FOR(i,4){
        number = number<<8;
        number = number|input[i];
    }
    return number;
}

void int_to_char(uint32_t input, char* output){
    FOR(i,4){
        output[3-i] = input%256;
        input = input>>8;
    }
    return;
}

string get_ip(struct sockaddr_in* ptr){
    char output[60];
    int ip = (ptr->sin_addr).s_addr;
    int part[4];
    FOR(i,4){
        part[i] = ip&0xFF;
        ip = ip>>8;
    }
    sprintf(output, "%d.%d.%d.%d",part[0],part[1],part[2], part[3]);
    string result = output;
    return result;
}

string common1;
bool file_rcv(int);
bool file_rcv(int mode=0){
    if(mode==1){
        my_rcv(1);
    }
    string filename, file_path;
    char tmp[HSM_BUF_SIZE];
    
    // (1): check and get filename:
    if(my_rcv() < 0) return false;
    if(buffer2[0] != 1){
        cerr<<"\nError: filename didn't recieved!\n";
        return false;
    }
    int block_size = HSM_BUF_SIZE - 1;
    
    sscanf( (char*) (buffer2+1) , "%s", tmp );
    filename = tmp;
    common1 = filename;
    file_path = user_path + "/" + filename;
    
    
    ofstream fout;
    fout.open(file_path.c_str(), ios::binary | ios::out);
    if(!fout){
        cerr<<"\nCouldn't create new file!!\n";
        return false;
    }
    
    
    // (2)(3): Recieving block files and EOF:
    int res, idx;
    while( true ){
        res = my_rcv();
        if(res<0){
            cerr<<"\nError (file_rcv) #1\n";
            return false;
        }
        if( buffer2[0] == 2 ){
            fout.write(  (char*) &buffer2[1], block_size );
        }else if(buffer2[0] == 3){
            idx = find_first_my_byte( buffer2, _F1 );
            fout.write(  (char*) &buffer2[1], idx-1 );
            fout.close();
            break;
        }else{
            cerr<<"\nError (file_rcv) #2\n";
            return false;
        }
    }
    buffer2[0] = -1;
    return true;
}

string file_rcv_str(int);
string file_rcv_str(int mode=0){
    bool res = file_rcv(mode);
    if( !res )
        return "Error!";
    return common1;
}



bool file_sender( string );
bool file_sender( string filename ){
    if(filename.size() >= 511){
        cerr<<"File name is too big!!\n";
        return false;
    }
    string file_path = user_path + "/" + filename;
    ifstream fin;
    fin.open(file_path.c_str(), ios::binary | ios::in);
    if(!fin){
        cerr<<"\nNo such file or directory!!\n";
        return false;
    }
    
    int block_size = HSM_BUF_SIZE - 1;

    // (0): A message to send new file
    buffer1[0] = 0;
    my_send(1);
    
    // (1): new file plus file name:
    buffer1[0] = 1;
    cpy2buf(buffer1, filename, 1);
    my_send();
    
    // (2): sending file blocks:
    int res;
    buffer1[0] = 2;
    setbuf_2byte(buffer1, 1, _F1);
    while( fin.read( (char*) &buffer1[1], block_size) ){
        res = my_send();
        if( res < 0){
            cerr<<"\nError: Couldn't send file block\n";
            return false;
        }
        setbuf_2byte(buffer1, 1, _F1);
    }
    fin.close();
    buffer1[0] = 3;
    res = my_send();
    if( res < 0){
        cerr<<"\nError: Couldn't send file block\n";
        return false;
    }
    return true;
}


#endif  // STRUCTS_HEADERS
