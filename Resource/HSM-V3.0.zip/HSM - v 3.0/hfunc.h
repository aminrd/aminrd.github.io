/*
 * File name: 
 * hfunc.h	
 * Description:  
 * Common and general functions
 * -------------------------------------------------
 * HSM ( version 3 )
 * Beagle Bone Black secure machine
 * kernel : Debian
 * by : 
 *		Amin Aghaee
 *		Superviros: Dr. Siavash Bayat-Sarmadi
 * Sharif University of Technology
 * Computer engineering department
 * All rights reserved(2016)
 * -------------------------------------------------
*/
#ifndef _HFUNC_h
#define _HFUNC_h

#include "hprot.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <ctype.h>
#include <iomanip>

// cryptography libraries: 
#include "./crypto_lib/mymd5.h"


#ifndef _SPL
#ifdef _WIN32	
	#define _SLP 10
    #include <conio.h>
#else		
	#define _SLP 0
    #include <termios.h>
    #include "linux_conio.h"
#endif
#endif

string tolower_str(string);
string tolower_str(string str){
    string output = str;
    FOR(i, str.size())
        output[i] = tolower( str[i] );
    return output;
}

string change_type (string, string);
string change_type (string fn, string n_type){
    if( n_type.size() != 3 )
        return fn;
    FOR(i,3)
    fn[ fn.size() + i - 3 ] = n_type[i];
    return fn;
}
string remove_ext (string);
string remove_ext (string fn){
    int idx = fn.size() - 1;
    FOR(i,fn.size())
        if( fn[i] == '.' )
            idx = i;
    return fn.substr(0, idx);
}

void waitbar(char);
void waitbar(char c){
	#ifdef _WIN32
		FOR(i,20){
			printf("%c%c",c,c);
			Sleep(_SLP);
		}		
	#else
		FOR(i,20){
			printf("%c%c",c,c);
			sleep(_SLP);
		}			
	#endif
	cout<<endl;
	return;
}
void wait_str_bar(string);
void wait_str_bar(string str){
	#ifdef _WIN32
		FOR(i,str.size()){
			printf("%c",str[i]);
			Sleep(_SLP/10);
		}		
	#else
		FOR(i,str.size()){
			printf("%c",str[i]);
			sleep(_SLP/10);
		}			
	#endif
	cout<<endl;
	return;
}

std::string string_to_hex(const std::string& input)
{
    static const char* const lut = "0123456789ABCDEF";
    size_t len = input.length();
    
    std::string output;
    output.reserve(2 * len);
    for (size_t i = 0; i < len; ++i)
    {
        const unsigned char c = input[i];
        output.push_back(lut[c >> 4]);
        output.push_back(lut[c & 15]);
    }
    return output;
}


void file_printer(string, int);
void file_printer(string ptof,int mode){
	// mode: 0->normal print, 1-> waitbar print, 2-> HEX print
	ifstream fin(ptof.c_str());
	string ll;
	while(getline(fin,ll))
		if(mode==0)
			cout<<ll<<"\n";
        else if(mode==2){
            cout<<string_to_hex(ll)<<endl;
        }else
			wait_str_bar(ll);
	fin.close();
	return;
}

void file2f_printer(string,string, int);
void file2f_printer(string from,string to,int mode){
	// mode: 0->append, 1->rewrite
	ifstream fin(from.c_str());
	ofstream fout;
	if(mode==1)
		fout.open (to.c_str(), std::ofstream::out | std::ofstream::trunc);
	else
		fout.open (to.c_str(), std::ofstream::out | std::ofstream::app);
	string ll;
	while(getline(fin,ll))
		fout<<ll<<"\n";
	fin.close();
	fout.close();
	return;
}

string file_2_string( string );
string file_2_string( string src){
    std::ifstream ifs(src.c_str());
    std::string content( (std::istreambuf_iterator<char>(ifs) ),
                        (std::istreambuf_iterator<char>()    ) );
    return content;
}

bool is_empty_line(string);
bool is_empty_line(string line){
    if(line.size() > 1)
        return false;
    if( line.size() <= 0 )
        return true;
    if( isspace(line[0]) )
        return true;
    return false;
}

unsigned int toInt(char);
unsigned int toInt(char c)
{
    if (c >= '0' && c <= '9') return      c - '0';
    if (c >= 'A' && c <= 'F') return 10 + c - 'A';
    if (c >= 'a' && c <= 'f') return 10 + c - 'a';
    return -1;
}

string hex_to_str( string );
string hex_to_str( string my_str){
    
    string str;
    FOR(i,my_str.size())
    if(isalnum(my_str[i]))
        str.push_back(my_str[i]);
    
    string output;
    int size = str.size()/2;
    FOR(i, size)
        output.push_back( 16*toInt(str[(i<<1)]) + toInt(str[(i<<1) + 1]) );

    return output;
}


void prepare_file(string, int);
void prepare_file(string p2f, int mode=0){
    vector<string> lines;
    string ll;
    
    ifstream fin(p2f.c_str());
    while(getline(fin, ll))
        lines.push_back(ll);
    fin.close();
    
    if( is_empty_line( lines[0] ) ) lines.erase(lines.begin());
    if( is_empty_line( lines[lines.size()-1] ) ) lines.erase(lines.end());
    
    if(mode == 1){
        FOR(i, lines.size())
            lines[i] = hex_to_str(lines[i]);
    }
    
    ofstream fout(p2f.c_str());
    FOR(i, lines.size())
        fout<<lines[i]<<"\n";
    fout.close();
    return;
}

void input_scanner(string, int);
void input_scanner(string dest, int mode=0){
    system(CLC);
    cout<<"Enter your input and press 'ESC' to exit\n";
    printf("%s\n",_myline);
    ofstream fout(dest.c_str());
    char key;
    do {
        key = getch();
        if( key==0 || key==-32 )
            {key = getch(); continue;}
        if( key == '\r' ){
            cout<<endl;
            fout<<endl;
        }else{
            fout<<key;
            cout<<key;
        }
        
    } while (key != ESC);
    fout.close();
    
    prepare_file(dest, mode);
    return;
}

string pconcat( string, string );
string pconcat( string p1, string p2){
    return p1 + "/" + p2;
}

void copy_file( const char* , const char* );
void copy_file( const char* srce_file, const char* dest_file ){
    std::ifstream srce( srce_file, std::ios::binary ) ;
    std::ofstream dest( dest_file, std::ios::binary ) ;
    dest << srce.rdbuf() ;
}
void copy_file( string , string );
void copy_file( string srce_file, string dest_file ){
    std::ifstream srce( srce_file.c_str(), std::ios::binary ) ;
    std::ofstream dest( dest_file.c_str(), std::ios::binary ) ;
    dest << srce.rdbuf() ;
}


void RENAME( string, string);
void RENAME( string from, string to ){
    std::rename(from.c_str(), to.c_str());
    return;
}
#endif
