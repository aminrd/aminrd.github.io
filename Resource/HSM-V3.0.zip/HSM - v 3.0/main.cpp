/*
 * File name: 
 * HSM-v3.0.cpp
 * Description:  
 * Main
 * -------------------------------------------------
 * HSM ( version 3 )
 * Beagle Bone Black secure machine
 * kernel : Debian
 * by : 
 *		Amin Aghaee
 *		Superviros: Dr. Siavash Bayat-Sarmadi
 * Sharif University of Technology
 * Computer engineering department
 * All rights reserved(2016)
 * -------------------------------------------------
*/
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include "hfunc.h" 
#include "acc_structure.h"
using namespace std;



// Global variables --------------------------------------------- 
acc_db DB1;
string cmd;
int ix_log = -1;
string user_path;
vector<string> cmd_list;
// --------------------------------------------------------------
#include "commands.h"


int main(){
    
	int cix;
	start();
    
	while(1){
		printf(">>");
		cin>>cmd;
		cix = cmd_idx(cmd);
		
		
		if(cix < 0){ 
			cout<<" -- Not a valid command! use: -help\n";
		}else if(cix <=4 ){
			if(cmd=="help"){
				help();
			}else if(cmd=="clc"){
				system(CLC);
			}else if(cmd=="exit"){
				my_exit();
				break;
			}else if(cmd=="login"){
                if(ix_log != -1){
                    printf("  You're already logged in!!\n");
                    continue;
                }
				login();				
			}else if(cmd=="new_acc"){
				NEW();				
			}			
		}else{
			if(ix_log == -1){
				printf(" You should login first! use: -help\n");
				continue;
			}
            if(cmd=="logout"){
                logout();
            }else if (cmd=="cert_mng"){
                cert_mng();
            }else if (cmd=="rsa_mng"){
                rsa_mng();
            }else if (cmd=="hash"){
                hash_mng();
            }else if (cmd=="enc"){
                Encryption();
            }else if (cmd=="dec"){
                Decryption();
            }else if (cmd=="other"){
                OTHER();
            }
		}		
			
	}
	
	
	#ifdef _WIN32
		system("pause");
	#endif	
}

