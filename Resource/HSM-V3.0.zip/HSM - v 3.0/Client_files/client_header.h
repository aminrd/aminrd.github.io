/*
 * File name: 
 * client_header.h	
 * Description:  
 * Server Header Files and Functions
 * -------------------------------------------------
 * HSM ( version 3 )
 * Beagle Bone Black secure machine
 * kernel : Debian
 * by : 
 *		Amin Aghaee
 *		Superviros: Dr. Siavash Bayat-Sarmadi
 * Sharif University of Technology
 * Computer engineering department
 * All rights reserved(2016)
 * -------------------------------------------------
*/
#ifndef _CLIENT_HEADER_h
#define _CLIENT_HEADER_h

#include <iostream>
#include <fstream>
#include <cstdint>
#include <cstdio>

#include "../network_lib.h"

string username, password;


string question(string);
string question(string Q){
    string res;
    cout<<Q<<endl;
    getline(cin, res);
    return res;
}

// (120-): Converting formats request
string convert_req(string, string , string);
string convert_req(string filename, string from, string to){
    from = tolower_str(from);
    to = tolower_str(to);
    file_sender(filename);
    
    if( from != "pem" && to != "pem" ) return "One side and just one side should be : PEM\n";
    if( from == "pem" && to == "pem" ) return "One side and just one side should be : PEM\n";
    
    if( from == "pem" )
        if( to == "der" )           buffer1[0] = 120;
        else if( to == "pkcs12" )   buffer1[0] = 121;
        else if( to == "pkcs7" )    buffer1[0] = 122;
        else return "Error!";
    else
        if( from == "der" )           buffer1[0] = 123;
        else if( from == "pkcs12" )   buffer1[0] = 124;
        else if( from == "pkcs7" )    buffer1[0] = 125;
        else return "Error!";
    my_send(1);
    filename = file_rcv_str(1);
    return "\n Output ready: \t" + filename + "\n";
}


// (80-89): hash algorithms
string get_hash(string, int, string);
string get_hash(string alg="md5", int type=0, string input="default\n"){
    // type : 0-> get hash for the input string_ input = hash input
    // type : 1-> get hash of the uploaded file_ input = filename
    uint8_t controler = 80;
    if( alg == "md5" )         controler += 0;
    else if( alg == "sha1" )   controler += 1;
    else if( alg == "sha256" ) controler += 2;
    else if( alg == "sha3" )   controler += 3;
    else
        return "Error!";
    if( type == 1 )
        controler += 4;
    
    buffer1[0] = controler;
    my_send(1);

    if( type == 1 ){
        file_sender(input);
    }
    cpy2buf(buffer1, input, 0);
    my_send();
    my_rcv();
    
    if( buffer2[0] != 89)
        return "Error!";
    vector<string> list = getstrings( &buffer2[1] );
    return list[0];
}


// (130) RSA Key generation req, get Public Key
string rsa_key_req(string, int, string);
string rsa_key_req(string mode, int byte_n, string pass, string key_name){
    mode = tolower_str(mode);
    if( mode != "des" && mode!="des3" )
        return "Mode Error!";
    if(byte_n != 1024 && byte_n != 2048 && byte_n != 4096)
        return "Key Size error!";
    
    buffer1[0] = 130;
    my_send(1);
    
    if(mode == "des")       buffer1[0] = 0;
    else                    buffer1[0] = 1;
    
    if(byte_n == 1024)      buffer1[1] = 0;
    if(byte_n == 2048)      buffer1[1] = 1;
    if(byte_n == 4096)      buffer1[1] = 2;
    
    cpy2buf(buffer1, pass + "  " + key_name, 2);
    my_send();
    
    string fn = file_rcv_str(1);
    return "\n Public Key: " + fn + "\n";
}

// (140-141) RSA Encryption, Decryption
string rsa_req(string, string, string);
string rsa_req(string type, string message, string key_name){
    type = tolower_str(type);
    string res;
    
    if( type[0] == 'e'  )
        buffer1[0] = 140;
    else if( type[0] == 'd'  )
        buffer1[0] = 141;
    else
        return "Error( rsa_req #1 )";
    my_send(1);
    
    if( type[0] == 'e'  ){
        if( file_sender( key_name ) == false)      return "Error( rsa_req #2 )";
    }else{
        cpy2buf(buffer1, remove_ext(key_name), 0);
    }
    if( file_sender( message ) == false)
        return "Error( rsa_req #3 )";
    res = file_rcv_str(1);
    return "\nOutput_File:\t" + res + "\n";
}

// (180-181) Encryption/ Decryptin (AES, DES, DES3):
string cipher_req(string, string, string, string, string, int);
string cipher_req( string type, string alg, string mode, string pass, string message, int size=128){
    alg = tolower_str(alg);
    mode = tolower_str(mode);    
    
    string res;
    if(type == "enc")       buffer1[0] = 180;
    else if(type == "dec")  buffer1[0] = 181;
    else
        return "Error( cipher_req #1 )";
    
    if( size!=128 && size!=192 && size!=256 )
        return "Error( cipher_req #2 )";
    if( alg != "aes" && alg!="des" && alg!="des3" )
        return "Error( cipher_req #3 )";
    my_send(1);
    
    if( size == 128 )       size = 1;
    else if( size == 192 )  size = 2;
    else                    size = 3;
    
    sprintf((char*) buffer1, "  %s  %s %s %d ", alg.c_str(), mode.c_str(), pass.c_str(), size);
    my_send();
    if( file_sender( message ) == false)
        return "Error( cipher_req #4 )";
    res = file_rcv_str(1);
    return "\nOutput_File:\t" + res + "\n";
}

// (10-13) Certificate Management
string get_cert_formats(int);
string get_cert_formats( int size ){
    if( size == 1024 )    buffer1[0] = 10;
    else if( size == 2048 )    buffer1[0] = 11;
    else if( size == 4096 )    buffer1[0] = 12;
    else
        return "Error!";
    my_send(1);
    
    my_rcv();
    if( buffer2[0] != 13 )
        return "Error!";
    vector<string> list = getstrings( &buffer2[1] );
    
    FOR(i,2)
        file_rcv(1);
    char msg[256];
    sprintf(msg, "\n -crt format:\t%s\n -csr format:\t%s\n", list[0].c_str(), list[1].c_str());
    string message = msg;
    return message;
}


string get_cert_form();
string get_cert_form(){
    char result[300];
    string tmp;
    cout<<"Please fill the following form completely:\n";
    username = question("Choose a username");
    password = question("Choose a password (at least 5 characters)");
    string IR = question("Your country? (2 Char) example: IR");
    string city = question("Your city? example: Tehran");
    string company = question("Your Company name? example: Sharif Univeristy of Technology");
    string Department = question("Your Department name? example: Computer Engineering Department");
    string website = question("Website? ex.: www.sharif.edu");
    sprintf(result,"/C=%s/ST=%s/L=%s/O=%s/OU=%s/CN=%s",IR.c_str(),city.c_str(),city.c_str(),company.c_str(),Department.c_str(),website.c_str());
    tmp = result;
    FOR(i,tmp.size())
        if( tmp[i] == ' ' )
            tmp[i] = '_';
    return tmp;
}

void cli_initial();
void cli_initial(){
    base_path = "./Client_files";
    fstream fin(base_path + "/" + "status.txt");
    int state;
    fin>>state;
    fin.close();
    if(state == 1) return;
    string form = get_cert_form();
    fstream fout(base_path + "/" + "status.txt");
    fout<<1<<endl;
    fout<<username<<endl;
    fout<<password<<endl;
    fout<<form<<endl;
    fout.close();
    return;
}

#endif
