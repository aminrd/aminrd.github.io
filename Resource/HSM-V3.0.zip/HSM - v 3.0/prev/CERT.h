//
//  CERT.h
//  
//
//  Created by Amin Aghaee and Sina Sharifi
//  Copyright (c) 1393 __SHARIF UNIVERISTY OF TECHNOLOGY__. All rights reserved
//

#ifndef _CERT_h
#define _CERT_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#ifndef FOR
#define FOR(i,x) for(i=0;i<(x);i++)
#endif

int CERT_NUM;
char cert_path[] = "./certificates/";

void GET_INPUT(char *filename){
    printf("Please type your input ~TEXT~ here\n");
    printf(" *NOTE*: to finish, type -:eof:- at the end\n");
    size_t nbytes = 200;
    ssize_t res = 0;
    char *my_line = NULL;
    
    FILE * output;
    output = fopen(filename, "w");
    res = getline(&my_line,&nbytes, stdin);
    
    while(strcmp(my_line, "-:eof:-\n") != 0){
        if(res == -1){
            printf("ERROR WHILE READING YOUR INPUT\n");
//            free(my_line);
            fclose(output);
        }
//        printf("%s",my_line);
        fprintf(output,"%s",my_line);
        my_line = NULL;
        res = getline(&my_line,&nbytes, stdin);
    }
    free(my_line);
    fclose(output);
    return;
}

void give_path(int index,char * com){
	char cmd[6];	
    int i;
    for(i=0;i<5;i++){
        cmd[4-i] = index%10 + '0';
        index /= 10;
    }
    cmd[5] = 0;
	strcpy (com,cmd);
	return;
}

void get_path(int number, char * output, char *type){
    output[0] = 0;
    char temp[10];
    give_path(number, temp);
    char MY_FILE[100] = "./certificates/";
    strcat(MY_FILE, temp);
    strcat(MY_FILE, type);
    strcpy(output, MY_FILE);
    return;
}


int file_cmp(char *file1, char *file2){
    FILE * F1;
    FILE * F2;
    F1 = fopen(file1, "r");
    F2 = fopen(file2, "r");
    
    char tmp1[200];
    char tmp2[200];
    int result = 1;
    
    while( !feof(F1) || !feof(F2)){
        fscanf(F1," %s",tmp1);
        fscanf(F2," %s",tmp2);
        if(strcmp(tmp1,tmp2) != 0){
            result = 0;
            break;
        }
    }
    
    fclose(F1);
    fclose(F2);
    return result;
}

void print_certificate(char * file){
    FILE * output;
    output = fopen(file, "r");
    int i;
    char tmp;
    while( !feof(output)){
        fscanf(output,"%c",&tmp);
        printf("%c",tmp);
    }
    return;
}
int verify_certificate(char * filename){
    int i;
    FOR(i,CERT_NUM){
        
    }
    return -1;
}


void print_file(char * filename){
    FILE* input;
    input = fopen(filename,"r");
    char tmp;
    while( !feof(input) ){
        fscanf(input,"%c",&tmp);
        printf("%c",tmp);
    }
    fclose(input);
    return;
}
                                 

#endif
