/* -------------------------------------------------
 * RSA - HSM 
 * to work in beagle boane black 
 * kernel : Angstrom (mini linux)
 * by : 
		Amin Aghaee
		Sina Sharifi
 * -------------------------------------------------
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "FUNC.h"



int main(){
//    GET_INPUT("INPUT");
	INIT();
	char task [100];
	while(strcmp(task,"exit") != 0){
        printf("\n++++++++++++++++++++\n");
        printf("-> tasktes are: \n");
        printf("-> exit \n");    
        printf("-> new \n"); 
        printf("-> login \n");  
        printf("++++++++++++++++++++++\n"); 
		scanf(" %s",task);
		if(strcmp(task,"new")==0) 	
			NEW();
		else if(strcmp(task,"login")==0){
			int index = LOGIN();
			if(index >= 0)
				TASK_MANAGER(index);
		}									
	}
	SAVE();
	return 0;
}

