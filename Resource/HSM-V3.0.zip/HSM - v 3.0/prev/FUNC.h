/* 
 * -------------------------------------------------
 * RSA - HSM ( version 2 )
 * to run in beagle boane black 
 * kernel : Angstrom (mini linux)
 * by : 
		Amin Aghaee
		Sina Sharifi
 * -------------------------------------------------
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "CERT.h"

#ifndef _FUNC_H
#define _FUNC_H

#ifndef FOR
#define FOR(i,x) for(i=0;i<(x);i++)
#endif

#define MAX_LEN 20
#define MAX_USER 100

FILE *info;
int user_num;

struct ACC{
	int id;
	char name[MAX_LEN];
//	char password[MAX_LEN];
}users[MAX_USER];

int get_idx_by_name(char * name){
	int i=0;
	FOR(i,user_num)
		if(strcmp(name,users[i].name)==0)
			return i;
	return -1;		
}


void INIT(){
	info = fopen("./acc/acc_list.txt", "r"); 
	fscanf(info," %d", &user_num);
//    fscanf(info," %d", &CERT_NUM);
	int i;
		int _id;
		char _name[MAX_LEN];
//		char _password[MAX_LEN];
	FOR(i,user_num){
		fscanf(info," %d", &_id);
		fscanf(info," %s", _name);
//		fscanf(info," %s", _password);
		users[i].id = _id;
		int j;
		FOR(j,MAX_LEN){
			users[i].name[j] = _name[j];
//			users[i].password[j] = _password[j];
		}
	}
	fclose(info);
	return ;
}

void SAVE(){
	info = fopen("./acc/acc_list.txt", "w");
	fprintf(info,"%d\n",user_num);
	int i;
	FOR(i,user_num){
		fprintf(info,"%d  ",users[i].id);
		fprintf(info,"%s  ",users[i].name);
//		fprintf(info,"%s  ",users[i].password);
	}
	fclose(info);
	return;
}



void NEW(){
		int _id;
//		char _name[MAX_LEN];
//		char _password[MAX_LEN];
//		char _P_verifie[MAX_LEN];
//	printf(" # NEW ACCOUNT !\n");
//	printf(" # Please Enter your id: ");
	_id = user_num;
    printf("YOUR ID NUMBER IS : %d\n",_id);
//	printf(" # Please Enter your user name: ");	
//	scanf("%s",_name);
//	printf(" # Please Enter your password: ");		
//	scanf("%s",_password);	
//	printf(" # Re - Please Enter your password: ");		
//	scanf("%s",_P_verifie);	
	
	int i=0;
//	if(strcmp(_password,_P_verifie) != 0){
//			printf(" -- ERROR: new account failed !\n");
//			return;
//	}
	users[user_num].id = _id;
//	int j;
//	FOR(j,MAX_LEN){
//			users[user_num].name[j] = _name[j];
////			users[user_num].password[j] = _password[j];
//	}
    
    char KEY[] = "key.pem";
    char REQ[] = "req.pem";    
    
    char KEYFILE[20];
    char REQFILE[20];
    
    give_path(_id, KEYFILE);
    give_path(_id, REQFILE);
    
    strcat(KEYFILE, KEY);
    strcat(REQFILE, REQ);
    
//    printf("key = %s\n",KEYFILE);
//    printf("req = %s\n",REQFILE);
    
    char makecert[100] = "openssl req -newkey rsa:1024 -keyout ./certificates/";
    strcat(makecert, KEYFILE);
    strcat(makecert, " -out ./certificates/");
    strcat(makecert, REQFILE);   
    user_num++;
    system(makecert);
    
	printf(" -- ACC made successfully\n");
    printf(" -- Your Certificate is ready, keep it safe : \n");
    
    char rout[30] = "./certificates/";
    strcat(rout, REQFILE);
    print_certificate(rout);
	return;
}

int LOGIN(){
    int uid = 0;
    int verify = -1;
    char FNAME[] = "input_cert.pem";
    printf("Please ENTER your certificate here: \n");    
    GET_INPUT(FNAME);
    char path[50];
    int res;
    int found = -1;
    
    FOR(uid, user_num){
        get_path(uid, path, "req.pem");
        res = file_cmp(FNAME, path);
        if(res){
            found = uid;
            break;
        }
              
    }
    if(found == -1)
        printf("^^^^ERROR: not found^^^^^\n");    
    system("openssl req -in input_cert.pem -text -verify -out detail_input_cert.txt");
    if(found >= 0){
        get_path(found, path, "key.pem");
        char TMP [200] = "cp ";
        strcat(TMP, path);
        strcat(TMP, " ./temp_key.pem");
        system(TMP);
//        printf("%s\n",TMP);
    }
	return found;
}

void print_tasks(){
    printf("\n================\n");
    printf("-> tasks are: \n");
    printf("-> logout \n");    
    printf("-> encrypt \n");
    printf("-> decrypt \n");
    printf("-> sign \n");
    printf("-> verification \n");
    printf("-> ECC \n");
    printf("-> get_public \n");    
    printf("\n");    
    return;
}
void TASK_MANAGER(int index){
	printf(" ---- USER TASK MANAGER ------- \n");
    printf("Your ID is : %d\n\n",index);
	char * task = (char*) malloc(100 * sizeof(char));
while(strcmp(task,"logout") != 0){	
    print_tasks();
	scanf(" %s", task);
	if(strcmp(task,"sign")==0){
        GET_INPUT("INPUT");
        printf("Enter your password:\n");
        system("openssl rsautl -sign -in INPUT -inkey temp_key.pem ");
	}else if(strcmp(task,"get_public")==0){
        printf("Enter your password:\n");
        system("openssl rsa -in temp_key.pem -pubout");
	}else if(strcmp(task, "encrypt")==0){
        GET_INPUT("INPUT");
        int mode=-1;
        printf(" plese enter encryption mode: \n ");
        printf(" # 0 - AES \n ");
        printf(" # 1 - RSA \n ");
        printf(" # 2 - 3DES \n ");
        scanf(" %d",&mode);
        
        switch(mode){
            case 0:
                printf(" plese enter AES encryption mode: \n ");
                printf(" # 0 - CBC \n ");
                printf(" # 1 - CTR \n "); 
                scanf(" %d",&mode);
                if(mode == 0){
                    system("openssl aes-256-cbc -in INPUT -out INPUT.ssl");
                    print_file("INPUT.ssl");
                }                
                break;
            case 1:
                printf("Encrypting with your public key is running:\n");
                printf("Enter your password:\n");
                system("openssl rsa -in temp_key.pem -pubout -out temp_public.pem -outform PEM");
                system("openssl rsautl -encrypt -inkey temp_public.pem -pubin -in INPUT -out INPUT.ssl");
                printf("encryption doce --> INPUT.ssl\n");
                print_file("INPUT.ssl");
                break;
            case 2:
                printf("Encrypting with 3DES is now running:\n");                
                system("openssl des3 -salt -in INPUT -out INPUT.ssl");            
                print_file("INPUT.ssl");
                break;
            default:
                break;
        }
    }else if(strcmp(task, "decrypt")==0){
//        GET_INPUT("INPUT.ssl");
        int mode=-1;
        printf(" plese enter decryption mode: \n ");
        printf(" # 0 - AES \n ");
        printf(" # 1 - RSA \n ");
        printf(" # 2 - 3DES \n ");
        scanf(" %d",&mode);
        
        switch(mode){
            case 0:
                printf(" plese enter AES decryption mode: \n ");
                printf(" # 0 - CBC \n ");
                printf(" # 1 - CTR \n "); 
                scanf(" %d",&mode);
                if(mode == 0){
                    system("openssl aes-256-cbc -d -in INPUT.ssl");
                }
                break;
            case 1:
                printf("Decrypting with your private key is now running:\n");
                printf("Enter your password:\n");
                system("openssl rsautl -decrypt -inkey temp_key.pem -in INPUT.ssl");
                break;
            case 2:
                printf("Decrypting with 3DES is now running:\n");
                system("openssl des3 -d -salt -in INPUT.ssl");
                break;
            default:
                break;
        }        
    }else if(strcmp(task, "verification")==0){
        GET_INPUT("INPUT");
        printf("Enter your password:\n");
        system("openssl rsautl -verify -in INPUT -inkey temp_key.pem");
    }else if(strcmp(task, "ECC")==0){
        printf("NEW ECC ec_param \n");
        system("openssl ecparam -out ec_param.pem -name prime192v1 -param_enc explicit");
        printf("Your public parts is : \n");
        system("openssl ec -in ec_param.pem -pubout -out temp_public.pem");
        print_file("temp_public.pem");
    }
}
	return;
}

#endif
