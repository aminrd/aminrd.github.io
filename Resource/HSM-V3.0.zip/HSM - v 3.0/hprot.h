/*
 * File name: 
 * hprot.h	
 * Description:  
 * Common and general prototypes global variables
 * -------------------------------------------------
 * HSM ( version 3 )
 * Beagle Bone Black secure machine
 * kernel : Debian
 * by : 
 *		Amin Aghaee
 *		Superviros: Dr. Siavash Bayat-Sarmadi
 * Sharif University of Technology
 * Computer engineering department
 * All rights reserved(2016)
 * -------------------------------------------------
*/
#ifndef _HPROT_h
#define _HPROT_h

#include <iostream>
#include <cstdio>
using namespace std;

#ifndef ESC
#define ESC 27
#endif

#ifndef FORC
#define FORC(i,x) for(i=0;i<(x);i++)
#endif

#ifndef FOR
#define FOR(i,x) for(int i=0;i<(x);i++)
#endif

#ifdef _WIN32
	#include <windows.h>
	#define CLC "cls"
#else
	#include <unistd.h>
	#define CLC "clear"
#endif


char _myline[] = "--------------------------------------------------";

// directories: 

string pth2_acc = "./accounts/";
string pth2_cryp = "./crypto_lib/";

//-------------



#endif
