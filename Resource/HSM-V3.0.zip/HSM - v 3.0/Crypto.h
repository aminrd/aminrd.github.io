/*
 * File name:
 * Crypto.h
 * Description:
 * Cryptography functions
 * -------------------------------------------------
 * HSM ( version 3 )
 * Beagle Bone Black secure machine
 * kernel : Debian
 * by :
 *		Amin Aghaee
 *		Superviros: Dr. Siavash Bayat-Sarmadi
 * Sharif University of Technology
 * Computer engineering department
 * All rights reserved(2016)
 * -------------------------------------------------
 */

#ifndef _Crypto_h
#define _Crypto_h

#include <iostream>
#include <fstream>

#include "hfunc.h"
#include "./crypto_lib/sha1.h"
#include "./crypto_lib/sha3.h"
#include "./crypto_lib/sha256.h"


// Generate a Self-Signed Certificate from an Existing Private Key and CSR
void crt_gen();
void crt_gen(){
    char cmdC[300];
    sprintf(cmdC,"openssl x509 -signkey %s/pkey.key -in %s/Cert.csr -req -days 365 -out %s/SS.crt", user_path.c_str(),user_path.c_str(),user_path.c_str());
    system(cmdC);
    return;
}

bool create_cert(int, string);
bool create_cert(int byte_n, string subj=" "){
    if(byte_n != 1024 && byte_n != 2048 && byte_n != 4096)
        return false;
    char cmdC[300];
    if(subj == " ")
        sprintf(cmdC, "openssl req -newkey rsa:%d -nodes -keyout %s/pkey.key -out %s/Cert.csr",byte_n,user_path.c_str(),user_path.c_str());
    else
        sprintf(cmdC, "openssl req -newkey rsa:%d -nodes -keyout %s/pkey.key -out %s/Cert.csr -subj %s",byte_n,user_path.c_str(),user_path.c_str(), subj.c_str());
    
    cout<<cmdC<<endl;
    system(cmdC);
    system(CLC);
    crt_gen();
    return true;
}

void view_cert(string);
void view_cert(string cert_name="Cert"){
    char cmdC[300];
    sprintf(cmdC,"openssl req -text -noout -verify -in %s/%s.csr",user_path.c_str(), cert_name.c_str());
    system(cmdC);
    return;
}


// Extract public key from private key (RSA)
void extract_public(string, string);
void extract_public(string key_name, string pass="12345"){
    char cmdC[300];
    sprintf(cmdC, "openssl rsa -in %s/%s.key -out %s/public.pem -passin pass:%s -outform PEM -pubout",user_path.c_str(), key_name.c_str(), user_path.c_str(), pass.c_str());
    printf("\n 8******************: \n %s\n", cmdC);
    system(cmdC);
    return;
}

// RSA Keygen: modes <DES, DES3> , Keysize <1024,2048,4096>
bool key_gen1(string, int, string, string, int);
bool key_gen1(string mode, int byte_n, string pass="12345", string keyname = "tmpkey", int run_type=0){
    if( mode != "des" && mode!="des3" )
        return false;
    if(byte_n != 1024 && byte_n != 2048 && byte_n != 4096)
        return false;
    
    char cmdC[300];
    if( run_type == 0){
        sprintf(cmdC,"openssl genrsa -%s -out %s.key -passout pass:%s %d", mode.c_str(), keyname.c_str() ,pass.c_str(), byte_n);
        system(cmdC);
    
        string my_dest = user_path + "/" + keyname + ".key";
        copy_file((keyname + ".key").c_str(), my_dest.c_str());
        extract_public(keyname, pass);
    }else{
        sprintf(cmdC,"openssl genrsa -%s -out %s/%s.key -passout pass:%s %d", mode.c_str(), user_path.c_str(), keyname.c_str() ,pass.c_str(), byte_n);
        system(cmdC);
        extract_public(keyname, pass);
    }
    system(CLC);
    return true;
}

// Verifying private key
bool verify_key1(string, string);
bool verify_key1(string keypath, string pass="12345"){
    char cmdC[300];
    sprintf(cmdC, "openssl rsa -check -passin pass:%s -in %s > ./TmpRam/tmp1.txt",pass.c_str(), keypath.c_str());
    ifstream fin("./TmpRam/tmp1.txt");
    
    string line;
    while(getline(fin,line)){
        if(line == "RSA key ok")
            return true;
    }
    return false;
}

// Convert PEM to DER (Certificate management)
void pem_to_der(string, string);
void pem_to_der(string cert_name = "SS", string dername="SSder"){
    char cmdC[300];
    sprintf(cmdC, "openssl x509 -in %s/%s.crt -outform der -out %s/%s.der",user_path.c_str(), cert_name.c_str(), user_path.c_str(), dername.c_str());
    system(cmdC);
    return;
}
// Convert DER to PEM (Certificate management)
void der_to_pem(string, string);
void der_to_pem(string dername="SSder", string cert_name = "SS"){
    char cmdC[300];
    sprintf(cmdC, "openssl x509 -inform der -in %s/%s.der -out %s/%s.crt",user_path.c_str(), dername.c_str(), user_path.c_str(), cert_name.c_str());
    system(cmdC);
    return;
}
//Convert PEM to PKCS12
void pem_to_p12(string, string, string);
void pem_to_p12(string keyname="pkey", string cert_name = "SS", string p12name="PKCS12"){
    char cmdC[300];
    sprintf(cmdC, "openssl pkcs12 -inkey %s/%s.key -in %s/%s.crt -export -out %s/%s.pfx",user_path.c_str(), keyname.c_str(), user_path.c_str(), cert_name.c_str(), user_path.c_str(), p12name.c_str());
    system(cmdC);
    return;
}
//Convert PKCS12 to PEM
void p12_to_pem(string, string);
void p12_to_pem(string p12name="PKCS12", string cert_name = "SS"){
    char cmdC[300];
    sprintf(cmdC, "openssl pkcs12 -in %s/%s.pfx -nodes -out %s/%s.crt",user_path.c_str(), p12name.c_str(), user_path.c_str(), cert_name.c_str());
    system(cmdC);
    return;
}

//Convert PEM to PKCS7
void pem_to_p7(string, string);
void pem_to_p7(string cert_name = "SS", string p7name="PKCS7"){
    char cmdC[300];
    sprintf(cmdC, "openssl crl2pkcs7 -nocrl -certfile %s/%s.crt -out %s/%s.p7b",user_path.c_str(), cert_name.c_str(), user_path.c_str(), p7name.c_str());
    system(cmdC);
    return;
}

//Convert PKCS7 to PEM
void p7_to_pem(string, string);
void p7_to_pem(string p7name="PKCS7", string cert_name = "SS"){
    char cmdC[300];
    sprintf(cmdC, "openssl pkcs7 -in %s/%s.p7b -print_certs -out %s/%s.crt",user_path.c_str(), p7name.c_str(), user_path.c_str(), cert_name.c_str());
    system(cmdC);
    return;
}

// RSA Encryption
void rsa_enc(string);
void rsa_enc(string p_to_key){ // Path to Public Key
    char cmdC[300];
    sprintf(cmdC, "openssl rsautl -encrypt -inkey %s -pubin -in ./TmpRam/tmpmsg.txt -out ./TmpRam/tmpfile.ssl",p_to_key.c_str());
    system(cmdC);
    return;
}

// RSA Decryption
void rsa_dec(string);
void rsa_dec(string p_to_key){ // Path to Private Key
    char cmdC[300];
    sprintf(cmdC, "openssl rsautl -decrypt -inkey %s -in ./TmpRam/tmpfile.ssl -out ./TmpRam/tmpmsg.txt",p_to_key.c_str());
    system(cmdC);
    return;
}

// General Encryptions: (AES, DES, DES3) (128,192,256) (CBC)
bool encryption(string, string, string, int);
bool encryption(string alg, string mode, string pass, int size = 128){ // Default size is 128
    if( size!=128 && size!=192 && size!=256 )
        return false;
    if( alg != "aes" && alg!="des" && alg!="des3" )
        return false;
    char cmdC[300];
    
    if(alg == "aes")
        sprintf(cmdC, "openssl aes-%d-%s -e -in ./TmpRam/tmpmsg.txt -out ./TmpRam/tmpfile.ssl -k pass:%s",size,mode.c_str(),pass.c_str());
    else if(alg == "des" )
        sprintf(cmdC, "openssl des-%s -e -in ./TmpRam/tmpmsg.txt -out ./TmpRam/tmpfile.ssl -k pass:%s",mode.c_str(),pass.c_str());
    else // DES3
        sprintf(cmdC, "openssl des-ede3-%s -e -in ./TmpRam/tmpmsg.txt -out ./TmpRam/tmpfile.ssl -k pass:%s",mode.c_str(),pass.c_str());
    system(cmdC);
    return true;
}

// General Decryptions: (AES, DES, DES3) (128,192,256) (CBC)
bool decryption(string, string, string, int);
bool decryption(string alg, string mode, string pass, int size = 128){ // Default size is 128
    if( size!=128 && size!=192 && size!=256 )
        return false;
    if( alg != "aes" && alg!="des" && alg!="des3" )
        return false;
    char cmdC[300];
    
    if(alg == "aes")
        sprintf(cmdC, "openssl aes-%d-%s -d -in ./TmpRam/tmpfile.ssl -out ./TmpRam/tmpmsg.txt -k pass:%s",size,mode.c_str(),pass.c_str());
    else if(alg == "des" )
        sprintf(cmdC, "openssl des-%s -d -in ./TmpRam/tmpfile.ssl -out ./TmpRam/tmpmsg.txt -k pass:%s",mode.c_str(),pass.c_str());
    else // DES3
        sprintf(cmdC, "openssl des-ede3-%s -d -in ./TmpRam/tmpfile.ssl -out ./TmpRam/tmpmsg.txt -k pass:%s",mode.c_str(),pass.c_str());
    system(cmdC);
    return true;
}



// Hashing Algorithms:
string myhash_str( int , string);
string myhash_str( int type, string content){
    // type : 0->md5, 1->sha1, 2->sha256, 3->sha3
    string hash_result;
    
    SHA1 sha1;
    SHA256 sha256;
    SHA3 sha3;
    switch (type) {
        case 0:
            hash_result = md5(content);
            break;
        case 1:
            hash_result = sha1(content.c_str(), content.size());
            break;
        case 2:
            hash_result = sha256(content.c_str(), content.size());
            break;
        default:
            hash_result = sha3(content.c_str(), content.size());
            break;
    }
    return hash_result;
}

// Hashing Algorithms:
string myhash( int , string);
string myhash( int type, string p2f){
    // type : 0->md5, 1->sha1, 2->sha256, 3->sha3
    string content = file_2_string(p2f);
    string hash_result;
    
    SHA1 sha1;
    SHA256 sha256;
    SHA3 sha3;
    switch (type) {
        case 0:
            hash_result = md5(content);
            break;
        case 1:
            hash_result = sha1(content.c_str(), content.size());
            break;
        case 2:
            hash_result = sha256(content.c_str(), content.size());
            break;
        default:
            hash_result = sha3(content.c_str(), content.size());
            break;
    }
    return hash_result;
}


#endif


















