/*
 * File name: 
 * commands.h	
 * Description:  
 * Parsing and managing users commands
 * -------------------------------------------------
 * HSM ( version 3 )
 * Beagle Bone Black secure machine
 * kernel : Debian
 * by : 
 *		Amin Aghaee
 *		Superviros: Dr. Siavash Bayat-Sarmadi
 * Sharif University of Technology
 * Computer engineering department
 * All rights reserved(2016)
 * -------------------------------------------------
*/
#ifndef _COMMANDS_h
#define _COMMANDS_h
#include "Crypto.h"

void start();
void start(){
	ifstream fin("./data/command_list.txt");
	string cmd;
	while(fin>>cmd)
		cmd_list.push_back(cmd);
	fin.close();
	
	system(CLC);
	wait_str_bar("  Welcome!\n");
	file_printer("./data/about.txt",1);
	return;
}

int cmd_idx(string);
int cmd_idx(string cmd){
	FOR(i,cmd_list.size())
		if(cmd_list[i] == cmd)
			return i;
	return -1;	
}

void help();
void help(){
	system(CLC);
	file_printer("./data/help.txt",0);
	return;
}
void my_exit();
void my_exit(){
	system(CLC);
	wait_str_bar("  -----  Good Bye!  -----\n");
	return;
}
void login();
void login(){
	string a,b;
	cout<<"  username: ";
	cin>>a;
	cout<<"  password: ";
	cin>>b;
	user_path = DB1.login(a,b);
	if( user_path == "-1" ){
		cout<<" Invalid Username or Password! use:-new to signup or -help\n";
		return;
	}
    user_path = pth2_acc + user_path;
	cout<<" Successfully logged in\n";
	ix_log = DB1.find_username(a);
	return;
}
void logout();
void logout(){
	user_path = "-1";
	ix_log = -1;
	system(CLC);
	cout<<" Logged out\n";
	return;
}



void NEW();
void NEW(){
	ACC tmp; 
	bool res = false;
	while(res == false){
		cout<<"  username?: ";
		cin>>tmp.username;
		cout<<"  password?: ";
		cin>>tmp.password;	
		res = DB1.create_new(tmp);	
		if(!res)	
			cout<<"  This username currently exist!\n";	
	}
    cout<<"  Your account made successfully\n  please take time and complete your certificate(2048 bytes) form"<<endl;
	ix_log = DB1.get_user_number() - 1;
	user_path = pth2_acc + DB1.users[ix_log].pth2_dir;
    bool test = create_cert(2048);
	return;
}

void update_cert();
void update_cert(){
    int type;
    cout<<"  Cert type(1024,2048,4096): ? ";
    cin>>type;
    if(create_cert(type) == false)
        cout<<"  Unsupported type. Updating certificate failed\n";
    return;
}


// RSA Management:
void rsa_mng();
void rsa_mng(){
    cout<<" -- Press number:\n";
    cout<<" -- 0 : RSA Key Generation\n";
    cout<<" -- 1 : Get Public Key\n";
    cout<<" -- 2 : Verify RSA Key \n";
    cout<<" -- Otherwise : quit \n";

    int sel,t1;
    string s1;
    bool res;
    
    cin>>sel;
    
    switch (sel) {
        // -----------------------------------------------------------------------------
        case 0:
            cout<<" Please Enter your type(des or des3) and key_size(1024,2048,4096)\n";
            cin>>s1>>t1;
            res = key_gen1(s1, t1);
            if(res == false){
                cout<<"Unsupported Type or Size\n";
                return;
            }else{
                file_printer("tmpkey.key",0);
                cout<<" Do you want to save this key in your profile?(y/n)\n";
                cin>>s1;
                if( s1[0]=='y' || s1[0]=='Y' ){
                    cout<<"Enter a name for this key (for future purposes)\n";
                    cin>>s1;
                    file2f_printer("tmpkey.key",user_path+"/"+s1+".key", 1);
                }else
                    break;
            }
            break;
        // -----------------------------------------------------------------------------
        case 1:
            cout<<" Do you have any key other than your main key? (y/n)\n";
            cin>>s1;
            if( s1[0]=='y' || s1[0]=='Y' ){
                cout<<" Please enter the name of your key\n";
                cin>>s1;
                extract_public(s1);
            }else{
                extract_public("pkey");
            }
            file_printer(user_path +"/public.pem",0);
            break;
        // -----------------------------------------------------------------------------
        case 2:
            input_scanner("./TmpRam/tmpkey.txt");
            res = verify_key1("./TmpRam/tmpkey.txt");
            if(res == true)
                cout<<" \nThis key is verified \n";
            else
                cout<<" \nThis key is not valid !\n";
            break;
        // -----------------------------------------------------------------------------
        default:
            return;
    }
    cout<<" -Done\n";
    return;
}

// Encryption functions:
void Encryption();
void Encryption(){
    string enc_type, p2f, mode, pass;
    int ksize;
    bool res=false;

    
    p2f = "./TmpRam/tmpmsg.txt";
    cout<<" Encryption Algorithm? (RSA, DES, DES3, AES)? \n";
    cin>>enc_type;
    cout<<" Encryption Password (at least 5 characters)? \n";
    cin>>pass;
    input_scanner(p2f);
    
    if( enc_type[0]=='A' || enc_type[0]=='a' ){
        
        cout<<" Encryption mode? \n";
        cin>>mode;
        cout<<" Key size? \n";
        cin>>ksize;
        res = encryption("aes", mode, pass, ksize);
        
    }else if( enc_type[0]=='R' || enc_type[0]=='r' ){
        
        cout<<" Enter the name of your PEM(public key) file: \n";
        cin>>mode;// mode here = PEM file name
        rsa_enc(user_path + "/" + mode + ".pem");
        
    }else if( enc_type[0]=='D' || enc_type[0]=='d' ){
        cout<<" Encryption mode? \n";
        cin>>mode;
        
        if(enc_type.size() <= 3){// DES
            res = encryption("des", mode, pass);
        }else{// DES3
            res = encryption("des3", mode, pass);
        }
        
    }
    if(res == false){
        cout<<"Invalid Algorithm, Mode, Keysize or Password! \n";
        return;
    }
    
    file_printer("./TmpRam/tmpfile.ssl", 2);
    return;
}

// Decryption functions:
void Decryption();
void Decryption(){
    string enc_type, p2f, mode, pass;
    int ksize;
    bool res=false;
    
    
    p2f = "./TmpRam/tmpfile.ssl";
    cout<<" Decryption Algorithm? (RSA, DES, DES3, AES)? \n";
    cin>>enc_type;
    cout<<" Decryption Password (at least 5 characters)? \n";
    cin>>pass;
    input_scanner(p2f, 1);
    
    if( enc_type[0]=='A' || enc_type[0]=='a' ){
        
        cout<<" Decryption mode? \n";
        cin>>mode;
        cout<<" Key size? \n";
        cin>>ksize;
        res = decryption("aes", mode, pass, ksize);
        
    }else if( enc_type[0]=='R' || enc_type[0]=='r' ){
        
        cout<<" Enter the name of your PEM(private key) file: \n";
        cin>>mode;// mode here = PEM file name
        rsa_dec(user_path + "/" + mode + ".pem");
        
    }else if( enc_type[0]=='D' || enc_type[0]=='d' ){
        cout<<" Decryption mode? \n";
        cin>>mode;
        
        if(enc_type.size() <= 3){// DES
            res = decryption("des", mode, pass);
        }else{// DES3
            res = decryption("des3", mode, pass);
        }
        
    }
    if(res == false){
        cout<<"Invalid Algorithm, Mode, Keysize or Password! \n";
        return;
    }
    
    file_printer("./TmpRam/tmpmsg.txt", 0);
    return;
}


// Hashing Management:
void hash_mng();
void hash_mng(){
    string type, sel, ptf;
    cout<<" Hash type? (md5, sha1, sha256, sha3)? \n";
    cin>>type;
    type = tolower_str(type);
    
    
    cout<<" Do you want to type in your input?(y/n) \n";
    cin>>sel;
    if(sel[0]=='y' || sel[0]=='Y'){
        input_scanner("./TmpRam/hashtmp.txt");
        ptf = "./TmpRam/hashtmp.txt";
    }else{
        cout<<" Please Enter the exact name of your file: \n";
        cin>>ptf;
    }
    int mytype = -1;
    
    if(type == "md5")         mytype = 0;
    else if(type == "sha1")   mytype = 1;
    else if(type == "sha256") mytype = 2;
    else if(type == "sha3")   mytype = 3;
    else{
        cout<<"\nInvalid command\n";
        return;
    }

    cout<<"\n"<<myhash(mytype, ptf)<<endl;
    return;
}

// Other enjoying commands:
void OTHER();
void OTHER(){
    string cmd, sel, p2f;
    system(CLC);
    file_printer("./data/Other_help.txt",0);
    cout<<" \nPlease Enter your command: \n";
    cin>>cmd;
    
    if(cmd=="hex_print"){
        cout<<" Do you wish to type in your data?(y/n) \n";
        cin>>sel;
        if(sel[0]=='y' || sel[0]=='Y'){
            input_scanner("./TmpRam/othertmp.txt");
            p2f = "./TmpRam/othertmp.txt";
        }else{
            cout<<" Please Enter the exact name of your file: \n";
            cin>>p2f;
        }
        file_printer(p2f, 2);
    }else{
        cout<<" Invalid _Other_ Command \n";
    }
    return;
}

// Certificate Management:
void cert_mng();
void cert_mng(){
    cout<<" -- Press number:\n";
    cout<<" -- 0 : view your certificate\n";
    cout<<" -- 1 : update your certificate\n";
    cout<<" -- 2 : Create DER \n";
    cout<<" -- 3 : Create PKCS#12 \n";
    cout<<" -- 4 : Create PKCS#7 \n";
    cout<<" -- 5 : Input a certificate \n";
    cout<<" -- Otherwise : quit \n";
    
    string tmp;
    int sel;
    cin>>sel;
    switch (sel) {
        case 0:
            view_cert();
            break;
        case 1:
            update_cert();
            break;
        case 2:
            pem_to_der();
            break;
        case 3:
            pem_to_p12();
            break;
        case 4:
            pem_to_p7();
            break;
        case 5:
            cout<<" \n Enter a name for the certificate (indicate PEM|CRT type)\n";
            cin>>tmp;
            input_scanner(user_path+"/"+tmp);
            break;
        default:
            return;
    }
    cout<<" -Done\n";
    return;
}

#endif
