/*
 * File name: 
 * HSM-v3.0.cpp
 * Description:  
 * HSM Server program
 * -------------------------------------------------
 * HSM ( version 3 )
 * Beagle Bone Black secure machine
 * kernel : Debian
 * by : 
 *		Amin Aghaee
 *		Superviros: Dr. Siavash Bayat-Sarmadi
 * Sharif University of Technology
 * Computer engineering department
 * All rights reserved(2016)
 * -------------------------------------------------
*/
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <string.h>
#include <stdlib.h>

#include "hfunc.h"
#include "network_lib.h"
#include "Crypto.h" 

#define MAX_CLIENT 2
#define BUF_SIZE 12

using namespace std;
int port;
string client_ip;
string cl_username, cl_password;

// --------------------------------------------------------------------------------------------------
// (80-89): hash algorithms
bool manage_hash(int);
bool manage_hash(int controler){
    if(controler > 83)
        file_rcv(1);
    
    my_rcv();
    vector<string> list = getstrings( &buffer2[0] );
    string result;
    if( controler > 83 ){ // file_hash_manager
        result = myhash( controler - 84, user_path + "/" + list[0]);
    }else{ // input_hash_manager
        result = myhash_str( controler - 80, list[0] );
    }
    
    buffer1[0] = 89; // Hash response
    cpy2buf( buffer1 , result, 1);
    if(my_send() < 0)
        return false;
    return true;
}

// (130): convert management:
bool rsa_key_manager();
bool rsa_key_manager(){
    bool res;
    my_rcv();
    string mode;
    int ksize;
    
    if(buffer2[0]==0)        mode = "des";
    else if(buffer2[0]==1)   mode = "des3";
    else                     return false;
    
    if(buffer2[1]==0)        ksize = 1024;
    else if(buffer2[1]==1)   ksize = 2048;
    else if(buffer2[1]==2)   ksize = 4096;
    else                     return false;
    
    vector<string> list = getstrings( &buffer2[2] );
    res = key_gen1(mode, ksize, list[0], list[1], 1);
    if(!res) return false;

    RENAME(pconcat(user_path, "public.pem"), pconcat(user_path, list[1]) + ".pem");
    file_sender(list[1] + ".pem");
    return true;
}

// (140-141): RSA Encryption/ Decryption Manager
bool rsa_manager( int );
bool rsa_manager( int controler ){
    string keyname;
    bool stt;
    vector<string> list;
    if( controler == 140 ){ // Encryption
        keyname = file_rcv_str(1);
    }else{ // Decryption
        list = getstrings( &buffer2[0] );
        keyname = list[0];
    }
    string msg = file_rcv_str(1);
    
    if( controler == 140 ){
        copy_file( pconcat(user_path, msg), "./TmpRam/tmpmsg.txt" );
        rsa_enc(pconcat(user_path, keyname));
        copy_file("./TmpRam/tmpfile.ssl", pconcat(user_path, "Output.ssl") );
        stt = file_sender("Output.ssl");
    }else{
        copy_file( pconcat(user_path, msg), "./TmpRam/tmpfile.ssl" );
        rsa_dec( pconcat(user_path, keyname + ".key") );
        copy_file("./TmpRam/tmpmsg.txt", pconcat(user_path, "Output.txt") );
        stt = file_sender("Output.txt");
    }
    return stt;
}

// (180-181): Cipher Manager (General Encryption Algorithms)
bool cipher_manager( int );
bool cipher_manager( int controler ){
    bool stt;
    my_rcv();
    vector<string> list = getstrings( &buffer2[0] );
    // list[0] = algorithm, list[1] = mode, list[2] = password, list[3] = size
    
    int size;
    if( list[3] ==  "1")        size = 128;
    else if( list[3] ==  "2")   size = 192;
    else if( list[3] ==  "3")   size = 256;
    else                        return false;
    string msg = file_rcv_str(1);
    
    if( controler == 180 ){
        copy_file( pconcat(user_path, msg), "./TmpRam/tmpmsg.txt" );
        encryption(list[0], list[1], list[2], size);
        copy_file("./TmpRam/tmpfile.ssl", pconcat(user_path, "Output.ssl") );
        stt = file_sender("Output.ssl");
    }else{
        copy_file( pconcat(user_path, msg), "./TmpRam/tmpfile.ssl" );
        decryption(list[0], list[1], list[2], size);
        copy_file("./TmpRam/tmpmsg.txt", pconcat(user_path, "Output.txt") );
        stt = file_sender("Output.txt");
    }
    return stt;
}


// (120-125): convert management:
bool convert_manager( int );
bool convert_manager( int controler ){
    string fn = file_rcv_str(1);
    fn = remove_ext(fn);
    bool res;
    
    if( controler < 123 ){
        if( controler == 120 ){ // PEM to DER
            pem_to_der(fn, fn);
            res = file_sender(fn + ".der");
        }else if(controler == 121){ // PEM to PKCS 12
            pem_to_p12("pkey", fn, fn);
            res = file_sender(fn + ".pfx");
        }else{ // PEM to PKCS 7
            pem_to_p7(fn, fn);
            res = file_sender(fn + ".p7b");
        }
    }else{
        if( controler == 123 ){ // DER to PEM
            der_to_pem(fn, fn);
            res = file_sender(fn + ".pem");
        }else if( controler == 124 ){ // PKCS 12 to PEM
            p12_to_pem(fn, fn);
            res = file_sender(fn + ".pem");
        }else{ // PKCS 7 to PEM
            pem_to_p7(fn, fn);
            res = file_sender(fn + ".pem");
        }
    }
    return res;
}

// (10,11,12): cert request , (13): cert response
bool generate_and_send_certs(int);
bool generate_and_send_certs(int ksize){
    if(ksize == 10) ksize = 1024;
    else if(ksize == 11) ksize = 2048;
    else if(ksize == 12) ksize = 4096;
    else
        return false;
    
    cerr<<"\n Server has recieved new certificate generation request\n";
    string p2f = user_path + "/" + "status.txt";
    cerr<<" - path request: "<<p2f<<endl;
    ifstream fin(p2f.c_str());
    
    if(!fin)
        return false;
    
    buffer1[0] = 13;
    cpy2buf(buffer1, "SS.crt Cert.csr ", 1);
    my_send();
    
    string tmp;
    FOR(i,4) {fin>>tmp;}
    fin.close();
    
    if( create_cert(ksize, tmp) == false)
        return false;

    if( file_sender( "Cert.csr" ) == false )
        return false;
    if( file_sender( "SS.crt" ) == false )
        return false;
    cerr<<"\n Server has finished generating certificate\n";
    return true;
}


// --------------------------------------------------------------------------------------------------
int main(int argc, const char * argv[]){
    base_path = "./Server_files";
    if(argc < 2)
        port = 8001; // Default server port
    else
        port = atoi(argv[1]);
    
    int socket_file_des = socket (PF_INET , SOCK_STREAM , 0);
    if ( socket_file_des == -1 ){
        cerr<<"ERROR: Main server couldn't be initialized!"<<endl;
        return 0;
    }
    struct sockaddr_in server_info;
    server_info.sin_family = AF_INET;
    server_info.sin_port = htons(port);
    server_info.sin_addr.s_addr = INADDR_ANY;
    bzero(&(server_info.sin_zero), 8);
    
    if (bind(socket_file_des, (struct sockaddr *) &server_info, sizeof(server_info)) == -1 ){
        cerr<<"ERROR: Main server bind"<<endl;
        return 0;
    }
    if ( listen(socket_file_des,MAX_CLIENT) == -1 ){
        cerr<<"ERROR: Main server listen error"<<endl;
        return 0;
    }
//    ------------------------------------------------------------------------------------------------------
    int sent_b;
    bool stat;
    struct sockaddr_in cli_addr ;
    unsigned int cli_len = sizeof(cli_addr);
    
    while(true){
        struct sockaddr client;
        sock_fd = accept(socket_file_des, (struct sockaddr *) &cli_addr, &cli_len);
        if(sock_fd >= 0){
            client_ip = get_ip(&cli_addr);
            cout<<"A new user from "<<client_ip<<" joined!"<<endl;
            user_path = base_path+ "/" +client_ip;
            make_dir(user_path);
            
            while(true){
                my_rcv(1);
                if( buffer2[0] == 0 ){
                    stat = file_rcv();
                }else if( 80 <= buffer2[0] && buffer2[0] <= 87 ){
                    stat = manage_hash(buffer2[0]);
                }else if( buffer2[0] == _F1){
                    stat = close(sock_fd);
                    break;
                }else if( 10 <= buffer2[0] && buffer2[0] <= 12){
                    stat = generate_and_send_certs( buffer2[0] );
                }else if( 120 <= buffer2[0] && buffer2[0] <= 125){
                    stat = convert_manager( buffer2[0] );
                }else if( 140 <= buffer2[0] && buffer2[0] <= 141){
                    stat = rsa_manager( buffer2[0] );
                }else if( 180 <= buffer2[0] && buffer2[0] <= 181){
                    stat = cipher_manager( buffer2[0] );
                }else if( buffer2[0] == 130){
                    stat = rsa_key_manager();
                }
                
                if(stat == false)
                    break;
            }
            
        }else{
            sleep(1);
            continue;
        }
    }
    
    
	#ifdef _WIN32
		system("pause");
	#endif	
}
























