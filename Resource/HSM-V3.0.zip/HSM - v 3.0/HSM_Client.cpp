/*
 * File name:
 * HSM_Client.cpp
 * Description:
 * HSM Client program
 * -------------------------------------------------
 * HSM ( version 3 )
 * Beagle Bone Black secure machine
 * kernel : Debian
 * by :
 *		Amin Aghaee
 *		Superviros: Dr. Siavash Bayat-Sarmadi
 * Sharif University of Technology
 * Computer engineering department
 * All rights reserved(2016)
 * -------------------------------------------------
 */
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <netdb.h>

#include <netinet/in.h>
#include <arpa/inet.h>


#include "hfunc.h"
using namespace std;

int server_port;
string server_ip;
#include "./Client_files/client_header.h"

int main(int argc, const char * argv[]){
    cli_initial();
    
    if(argc < 3){
        server_ip = "192.168.7.2";
        server_port = 8001; // Default server port
    }
    else{
        server_ip = argv[1];
        server_port = atoi(argv[2]);
    }
    user_path = base_path + "/" +server_ip;
    make_dir(user_path);
    
    sock_fd = socket ( PF_INET , SOCK_STREAM , 0);
    if ( sock_fd == -1 ){
        cout<<"Connection failed"<<endl;
        exit(0);
    }
    
    sockaddr_in server_info;
    server_info.sin_family = AF_INET;
    server_info.sin_port = htons(server_port);
    server_info.sin_addr.s_addr = inet_addr(server_ip.c_str());
    bzero(&(server_info.sin_zero), 8);
    if( connect( sock_fd, (struct sockaddr*) &server_info, sizeof(sockaddr_in)) == -1 ){
        cout<<"Connection failed"<<endl;
        exit(0);
    }
    char cmd[300];
    sprintf(cmd, "cp ./%s/status.txt %s/", base_path.c_str(), user_path.c_str());
    system(cmd);
    file_sender("status.txt");

    string _cmd, tmp;
    string my_arg[10];
    int my_argi[10];
    
    while(1){
        printf(">>");
        cin>>_cmd;
        if( _cmd == "clc" ){
            system(CLC);
        }else if(_cmd == "exit"){
            buffer1[0] = _F1;
            my_send(1);
            close(sock_fd);
            break;
        }else if(_cmd == "help"){
            file_printer( "./Client_files/help.txt", 0 );
        }else if(_cmd == "file"){
            printf("Enter your filename: ");
            cin>>tmp;
            file_sender(tmp);
        }else if(_cmd == "hash"){
            printf(" \nEnter function's parameters respectively: ");
            printf(" \n alg, type(0,1), input(your/filename)\n");
            cin>>my_arg[0]>>my_argi[0];
            getline(cin, my_arg[1]);
            tmp = get_hash(my_arg[0], my_argi[0], my_arg[1]);
            cout<<tmp<<endl;
        }else if(_cmd == "enc" || _cmd == "dec"){
            printf(" \nEnter function's parameters respectively: ");
            printf(" \n alg(AES,DES,DES3), mode(cbc,...), password, key_size(128,192,256) message filename\n");
            cin>>my_arg[0]>>my_arg[1]>>my_arg[2]>>my_argi[0]>>my_arg[3];
            tmp = cipher_req( _cmd, my_arg[0], my_arg[1], my_arg[2], my_arg[3], my_argi[0] );
            cout<<tmp<<endl;
        }else if(_cmd == "cert"){
            printf(" \nKey size? (1024,2048,4096) ");
            cin>>my_argi[0];
            tmp = get_cert_formats(my_argi[0]);
            cout<<tmp<<endl;
        }else if(_cmd == "convert"){
            printf(" \nEnter function's parameters respectively: ");
            printf(" \n filename, firrst format, second format. format:(pem, der, pkcs12, pkcs7)\n");
            cin>>my_arg[0]>>my_arg[1]>>my_arg[2];
            tmp = convert_req(my_arg[0], my_arg[1], my_arg[2]);
            cout<<tmp<<endl;
        }else if(_cmd == "rsa_key"){
            printf(" \nEnter function's parameters respectively: ");
            printf(" \n mode(DES,DES3), key_size(1024,2048,4096), password, key_name\n");
            cin>>my_arg[0]>>my_argi[0]>>my_arg[1]>>my_arg[2];
            tmp = rsa_key_req(my_arg[0], my_argi[0], my_arg[1], my_arg[2]);
            cout<<tmp<<endl;
        }else if(_cmd == "rsa"){
            printf(" \nEnter function's parameters respectively: ");
            printf(" \n Type(enc, dec), message filename, Keyname (PEM) \n");
            cin>>my_arg[0]>>my_arg[1]>>my_arg[2];
            tmp = rsa_req(my_arg[0], my_arg[1], my_arg[2]);
            cout<<tmp<<endl;
        }else
            printf(" Not a valid command\n");
    }
    
    #ifdef _WIN32
        system("pause");
    #endif
}





















